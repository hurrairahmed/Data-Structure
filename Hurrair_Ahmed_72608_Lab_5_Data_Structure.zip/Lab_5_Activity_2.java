/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.data_structure;

/**
 *
 * @author pc
 */
    import java.util.Stack;
import java.util.Scanner;

public class Lab_5_Activity_2 {

    // Returns precedence of an operator
    // Higher number = higher precedence
    static int precedence(char op) {
        switch (op) {
            case '*':
            case '/':
            case '%':
                return 2;
            case '+':
            case '-':
                return 1;
            default:
                return -1;
        }
    }

    // Check if a character is an operator
    static boolean isOperator(char c) {
        return c == '+' || c == '-' || c == '*' || c == '/' || c == '%';
    }

    // Check if a character is an operand (letter or digit)
    static boolean isOperand(char c) {
        return Character.isLetterOrDigit(c);
    }

    // Main conversion method
    static String infixToPostfix(String expression) {
        StringBuilder output = new StringBuilder();
        Stack<Character> stack = new Stack<>();

        for (int i = 0; i < expression.length(); i++) {
            char c = expression.charAt(i);

            // Skip spaces
            if (c == ' ') {
                continue;
            }

            // 1. If operand, add to output
            if (isOperand(c)) {
                output.append(c);
            }

            // 2. If opening parenthesis, push to stack
            else if (c == '(') {
                stack.push(c);
            }

            // 3. If closing parenthesis, pop until '(' is found
            else if (c == ')') {
                while (!stack.isEmpty() && stack.peek() != '(') {
                    output.append(stack.pop());
                }
                if (!stack.isEmpty() && stack.peek() == '(') {
                    stack.pop(); // discard '('
                }
            }

            // 4. If operator
            else if (isOperator(c)) {
                while (!stack.isEmpty()
                        && stack.peek() != '('
                        && precedence(stack.peek()) >= precedence(c)) {
                    output.append(stack.pop());
                }
                stack.push(c);
            }
        }

        // 5. Pop remaining operators
        while (!stack.isEmpty()) {
            output.append(stack.pop());
        }

        return output.toString();
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter Infix Expression:");
        String infix = sc.nextLine();

        String postfix = infixToPostfix(infix);

        System.out.println();
        System.out.println("Infix Expression:");
        System.out.println(infix);

        System.out.println();
        System.out.println("Postfix Expression:");
        System.out.println(postfix);

        sc.close();
    }
}
