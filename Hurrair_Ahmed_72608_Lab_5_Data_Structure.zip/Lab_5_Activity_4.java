/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.data_structure;
import java.util.Stack;
/**
 *
 * @author pc
 */
    public class Lab_5_Activity_4 {

    // --- Conversion (from Activity 2) ---
    static int precedence(char op) {
        switch (op) {
            case '*': case '/': case '%': return 2;
            case '+': case '-': return 1;
            default: return -1;
        }
    }

    static boolean isOperator(char c) {
        return c == '+' || c == '-' || c == '*' || c == '/' || c == '%';
    }

    static boolean isOperand(char c) {
        return Character.isLetterOrDigit(c);
    }

    // Converts infix to postfix with spaces between tokens
    static String infixToPostfix(String expression) {
        StringBuilder output = new StringBuilder();
        Stack<Character> stack = new Stack<>();

        for (int i = 0; i < expression.length(); i++) {
            char c = expression.charAt(i);
            if (c == ' ') continue;

            if (isOperand(c)) {
                output.append(c).append(' ');
            } else if (c == '(') {
                stack.push(c);
            } else if (c == ')') {
                while (!stack.isEmpty() && stack.peek() != '(') {
                    output.append(stack.pop()).append(' ');
                }
                if (!stack.isEmpty() && stack.peek() == '(') stack.pop();
            } else if (isOperator(c)) {
                while (!stack.isEmpty() && stack.peek() != '(' &&
                       precedence(stack.peek()) >= precedence(c)) {
                    output.append(stack.pop()).append(' ');
                }
                stack.push(c);
            }
        }
        while (!stack.isEmpty()) {
            output.append(stack.pop()).append(' ');
        }
        return output.toString().trim();
    }

    // --- Evaluation (Bonus) ---
    static int evaluatePostfix(String postfix) {
        Stack<Integer> stack = new Stack<>();
        String[] tokens = postfix.trim().split("\\s+");

        for (String token : tokens) {
            if (token.isEmpty()) continue;

            if (token.length() == 1 && isOperator(token.charAt(0))) {
                char op = token.charAt(0);
                int right = stack.pop();
                int left = stack.pop();

                int result;
                switch (op) {
                    case '+': result = left + right; break;
                    case '-': result = left - right; break;
                    case '*': result = left * right; break;
                    case '/': result = left / right; break;
                    default:  throw new IllegalArgumentException("Bad op: " + op);
                }
                stack.push(result);
            } else {
                stack.push(Integer.parseInt(token));
            }
        }
        return stack.pop();
    }

    public static void main(String[] args) {
        String infix = "5 + 3 * 2";
        String postfix = infixToPostfix(infix);
        int result = evaluatePostfix(postfix);

        System.out.println("Infix:   " + infix);
        System.out.println("Postfix: " + postfix);
        System.out.println("Result:  " + result);
    }

    
}
