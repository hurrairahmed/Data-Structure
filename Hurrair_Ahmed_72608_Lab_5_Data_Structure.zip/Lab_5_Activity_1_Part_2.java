/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.data_structure;

/**
 *
 * @author pc
 */
    class PQElement {
    int value;
    int priority;
    int order; // used to keep insertion order for same priority

    PQElement(int value, int priority, int order) {
        this.value = value;
        this.priority = priority;
        this.order = order;
    }
}

class SimplePriorityQueue {
    private PQElement[] arr;
    private int size;
    private int capacity;
    private int insertionCounter;

    SimplePriorityQueue(int capacity) {
        this.capacity = capacity;
        arr = new PQElement[capacity];
        size = 0;
        insertionCounter = 0;
    }

    boolean isEmpty() {
        return size == 0;
    }

    boolean isFull() {
        return size == capacity;
    }

    // 1. Insert element with priority
    void insert(int value, int priority) {
        if (isFull()) {
            System.out.println("Overflow! Priority Queue is full. Cannot insert " + value);
            return;
        }

        arr[size] = new PQElement(value, priority, insertionCounter++);
        size++;

        System.out.println("Inserted: value=" + value + ", priority=" + priority);
    }

    // 2. Remove highest priority element
    PQElement remove() {
        if (isEmpty()) {
            System.out.println("Underflow! Priority Queue is empty.");
            return null;
        }

        int bestIndex = 0;

        // Find highest priority element
        // Smaller priority number = higher priority
        for (int i = 1; i < size; i++) {
            if (arr[i].priority < arr[bestIndex].priority ||
                (arr[i].priority == arr[bestIndex].priority &&
                 arr[i].order < arr[bestIndex].order)) {
                bestIndex = i;
            }
        }

        PQElement removed = arr[bestIndex];

        // Shift elements left to fill the gap
        for (int i = bestIndex; i < size - 1; i++) {
            arr[i] = arr[i + 1];
        }

        arr[size - 1] = null;
        size--;

        System.out.println("Removed: value=" + removed.value +
                           ", priority=" + removed.priority);

        return removed;
    }

    // 3. Display all elements currently present
    void display() {
        if (isEmpty()) {
            System.out.println("Priority Queue is empty.");
            return;
        }

        System.out.println("Elements currently present (insertion order):");
        for (int i = 0; i < size; i++) {
            System.out.println("  Value: " + arr[i].value +
                               ", Priority: " + arr[i].priority);
        }
    }

    // Extra: show removal order without removing
    void displayInPriorityOrder() {
        if (isEmpty()) {
            System.out.println("Priority Queue is empty.");
            return;
        }

        PQElement[] temp = new PQElement[size];
        for (int i = 0; i < size; i++) {
            temp[i] = arr[i];
        }

        // Selection sort by priority, then insertion order
        for (int i = 0; i < size - 1; i++) {
            int min = i;

            for (int j = i + 1; j < size; j++) {
                if (temp[j].priority < temp[min].priority ||
                    (temp[j].priority == temp[min].priority &&
                     temp[j].order < temp[min].order)) {
                    min = j;
                }
            }

            PQElement t = temp[i];
            temp[i] = temp[min];
            temp[min] = t;
        }

        System.out.println("Elements in removal order (highest priority first):");
        for (PQElement e : temp) {
            System.out.println("  Value: " + e.value +
                               ", Priority: " + e.priority);
        }
    }
}

public class Lab_5_Activity_1_Part_2 {
    public static void main(String[] args) {
        SimplePriorityQueue pq = new SimplePriorityQueue(10);

        pq.insert(10, 3);
        pq.insert(20, 1);
        pq.insert(30, 2);
        pq.insert(40, 1);

        System.out.println("\n--- Current elements ---");
        pq.display();

        System.out.println("\n--- Priority order ---");
        pq.displayInPriorityOrder();

        System.out.println("\n--- Removing elements ---");
        pq.remove(); // 20
        pq.remove(); // 40
        pq.remove(); // 30
        pq.remove(); // 10
        pq.remove(); // underflow
    }
}
    
