/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.data_structure;

/**
 *
 * @author pc
 */
    /*
 * Circular Queue implementation using an array
 */

class CircularQueue {
    private int[] arr;
    private int front, rear, count, capacity;

    CircularQueue(int capacity) {
        this.capacity = capacity;
        arr = new int[capacity];
        front = -1;
        rear = -1;
        count = 0;
    }

    boolean isEmpty() {
        return count == 0;
    }

    boolean isFull() {
        return count == capacity;
    }

    void enqueue(int value) {
        if (isFull()) {
            System.out.println("Overflow! Queue is full. Cannot enqueue " + value);
            return;
        }

        if (isEmpty()) {
            front = 0;
            rear = 0;
        } else {
            rear = (rear + 1) % capacity;
        }

        arr[rear] = value;
        count++;
        System.out.println("Enqueued: " + value);
    }

    int dequeue() {
        if (isEmpty()) {
            System.out.println("Underflow! Queue is empty.");
            return -1;
        }

        int value = arr[front];

        if (count == 1) {
            front = -1;
            rear = -1;
        } else {
            front = (front + 1) % capacity;
        }

        count--;
        System.out.println("Dequeued: " + value);
        return value;
    }

    int peek() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return -1;
        }
        return arr[front];
    }

    void display() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return;
        }

        System.out.print("Queue elements: ");
        int i = front;
        for (int c = 0; c < count; c++) {
            System.out.print(arr[i] + " ");
            i = (i + 1) % capacity;
        }
        System.out.println();
    }
}

public class Lab_5_Activity_1_Part_1 {
    public static void main(String[] args) {
        CircularQueue q = new CircularQueue(5);

        q.enqueue(10);
        q.enqueue(20);
        q.enqueue(30);
        q.enqueue(40);

        q.dequeue();
        q.dequeue();

        q.enqueue(50);
        q.enqueue(60);

        System.out.println("Front element (peek): " + q.peek());
        q.display();
    }

    
}
