/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.data_structure;

/**
 *
 * @author pc
 */
    /*
 * Basic Priority Queue without tie-breaking
 */

class PQItemBasic {
    int value;
    int priority;

    PQItemBasic(int value, int priority) {
        this.value = value;
        this.priority = priority;
    }
}

class SimplePriorityQueueBasic {
    private PQItemBasic[] arr;
    private int size;
    private int capacity;

    SimplePriorityQueueBasic(int capacity) {
        this.capacity = capacity;
        arr = new PQItemBasic[capacity];
        size = 0;
    }

    boolean isEmpty() {
        return size == 0;
    }

    boolean isFull() {
        return size == capacity;
    }

    // 1. Insert an element with its priority
    void insert(int value, int priority) {
        if (isFull()) {
            System.out.println("Overflow! Priority Queue is full.");
            return;
        }

        arr[size] = new PQItemBasic(value, priority);
        size++;

        System.out.println("Inserted: value=" + value + ", priority=" + priority);
    }

    // 2. Remove the highest priority element
    PQItemBasic remove() {
        if (isEmpty()) {
            System.out.println("Underflow! Priority Queue is empty.");
            return null;
        }

        // Find highest priority = smallest priority number
        int bestIndex = 0;
        for (int i = 1; i < size; i++) {
            if (arr[i].priority < arr[bestIndex].priority) {
                bestIndex = i;
            }
        }

        PQItemBasic removed = arr[bestIndex];

        // Shift elements left to fill the gap
        for (int i = bestIndex; i < size - 1; i++) {
            arr[i] = arr[i + 1];
        }

        arr[size - 1] = null;
        size--;

        System.out.println("Removed: value=" + removed.value +
                           ", priority=" + removed.priority);

        return removed;
    }

    // 3. Display all elements currently present
    void display() {
        if (isEmpty()) {
            System.out.println("Priority Queue is empty.");
            return;
        }

        System.out.println("Priority Queue elements:");
        for (int i = 0; i < size; i++) {
            System.out.println("  Value: " + arr[i].value +
                               ", Priority: " + arr[i].priority);
        }
    }
}

public class Lab_5_Activity_1_Part_3 {
    public static void main(String[] args) {
        SimplePriorityQueueBasic pq = new SimplePriorityQueueBasic(10);

        // Insert example elements
        pq.insert(10, 3);
        pq.insert(20, 1);
        pq.insert(30, 2);
        pq.insert(40, 1);

        System.out.println("\nCurrent elements:");
        pq.display();

        System.out.println("\nRemoving elements according to priority:");
        pq.remove(); // 20
        pq.remove(); // 40
        pq.remove(); // 30
        pq.remove(); // 10
        pq.remove(); // underflow
    }

    
}
