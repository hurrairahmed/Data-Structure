/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab_02;

/**
 *
 * @author pc
 */
public class Lab_4_Activity_03 {

    static class Queue {
        private int[] arr;
        private int front;
        private int rear;
        private int size;
        private int capacity;

        public Queue(int capacity) {
            this.capacity = capacity;
            arr = new int[capacity];
            front = 0;
            rear = -1;
            size = 0;
        }

        public void enqueue(int value) {
            if (size == capacity) {
                System.out.println("Queue Overflow! Cannot enqueue " + value + " because queue is full.");
                return;
            }
            rear = (rear + 1) % capacity;
            arr[rear] = value;
            size++;
            System.out.println("Enqueued " + value);
        }

        public int dequeue() {
            if (size == 0) {
                System.out.println("Queue Underflow! Cannot dequeue because queue is empty.");
                return -1;
            }
            int value = arr[front];
            front = (front + 1) % capacity;
            size--;
            System.out.println("Dequeued " + value);
            return value;
        }

        public int peek() {
            if (size == 0) {
                System.out.println("Queue Underflow! Cannot peek because queue is empty.");
                return -1;
            }
            System.out.println("Front element is: " + arr[front]);
            return arr[front];
        }

        public void display() {
            if (size == 0) {
                System.out.println("Queue is empty.");
                return;
            }
            System.out.print("Queue elements (front to rear): ");
            for (int i = 0; i < size; i++) {
                int index = (front + i) % capacity;
                System.out.print(arr[index] + (i < size - 1 ? " " : ""));
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        Queue queue = new Queue(5);

        System.out.println("--- Required Queue Demonstration ---");
        queue.enqueue(10);
        queue.enqueue(20);
        queue.enqueue(30);
        queue.display();
        queue.peek();
        queue.dequeue();
        queue.display();

        System.out.println("\n--- Overflow and Underflow Demonstration ---");
        queue.dequeue();
        queue.dequeue();
        queue.dequeue();  
        queue.enqueue(1);
        queue.enqueue(2);
        queue.enqueue(3);
        queue.enqueue(4);
        queue.enqueue(5);
        queue.enqueue(6); // Overflow (capacity is 5)
    }
}
