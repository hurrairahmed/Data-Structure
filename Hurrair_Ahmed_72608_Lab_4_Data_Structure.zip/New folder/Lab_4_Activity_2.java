/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab_02;

/**
 *
 * @author pc
 */
public class Lab_4_Activity_2 {

    static class Stack {
        private int[] arr;
        private int top;
        private int capacity;

        public Stack(int capacity) {
            this.capacity = capacity;
            arr = new int[capacity];
            top = -1; 
        }

        public void push(int value) {
            if (top == capacity - 1) {
                System.out.println("Stack Overflow! Cannot push " + value + " because stack is full.");
                return;
            }
            arr[++top] = value;
            System.out.println("Pushed " + value);
        }

        public int pop() {
            if (top == -1) {
                System.out.println("Stack Underflow! Cannot pop because stack is empty.");
                return -1;
            }
            int value = arr[top--];
            System.out.println("Popped " + value);
            return value;
        }

        public int peek() {
            if (top == -1) {
                System.out.println("Stack Underflow! Cannot peek because stack is empty.");
                return -1;
            }
            System.out.println("Top element is: " + arr[top]);
            return arr[top];
        }

        public void display() {
            if (top == -1) {
                System.out.println("Stack is empty.");
                return;
            }
            System.out.print("Stack elements (top to bottom): ");
            for (int i = top; i >= 0; i--) {
                System.out.print(arr[i] + (i > 0 ? " " : ""));
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        Stack stack = new Stack(5);

        System.out.println("--- Required Stack Demonstration ---");
        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.display();
        stack.peek();
        stack.pop();
        stack.display();

        System.out.println("\n--- Overflow and Underflow Demonstration ---");
        stack.pop();
        stack.pop();
        stack.pop();   
        stack.push(1);
        stack.push(2);
        stack.push(3);
        stack.push(4);
        stack.push(5);
        stack.push(6); 
        
    }
}
