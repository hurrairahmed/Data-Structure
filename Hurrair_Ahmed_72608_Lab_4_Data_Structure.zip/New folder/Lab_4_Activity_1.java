/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab_02;

/**
 *
 * @author pc
 */
import java.util.Scanner;

public class Lab_4_Activity_1 {

    public static int linearSearch(int[] arr, int target) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
                return i;   
            }
        }
        return -1;        
    }

    public static int binarySearch(int[] arr, int target) {
        int low = 0;
        int high = arr.length - 1;

        while (low <= high) {
            int mid = low + (high - low) / 2;

            if (arr[mid] == target) {
                return mid;            
            } else if (arr[mid] < target) {
                low = mid + 1;          
            } else {
                high = mid - 1;       
            }
        }
        return -1;                      
    }

    public static void main(String[] args) {
        int[] linearArray = {45, 12, 78, 34, 23, 89, 56};
        int[] binaryArray = {12, 23, 34, 45, 56, 78, 89};

        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter target value to search: ");
        int target = scanner.nextInt();

        int linearResult = linearSearch(linearArray, target);
        int binaryResult = binarySearch(binaryArray, target);

        System.out.println("\nTarget value: " + target);

        if (linearResult != -1) {
            System.out.println("Linear Search: Found at index " + linearResult);
        } else {
            System.out.println("Linear Search: Not found (-1)");
        }

        if (binaryResult != -1) {
            System.out.println("Binary Search: Found at index " + binaryResult);
        } else {
            System.out.println("Binary Search: Not found (-1)");
        }

        scanner.close();
    }
}