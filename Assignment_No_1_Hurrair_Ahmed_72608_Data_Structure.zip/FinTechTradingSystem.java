/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.data_structure;

/**
 *
 * @author pc
 */

        import java.util.Scanner;
import java.util.Arrays;

// =====================================================================
// ASSET CLASS  (used by Arrays, Searching, Sorting, Watchlist, Portfolio)
// =====================================================================
class Asset {
    int assetId;
    String assetName;
    String assetType;
    double currentPrice;
    double percentageChange;

    Asset(int assetId, String assetName, String assetType,
          double currentPrice, double percentageChange) {
        this.assetId = assetId;
        this.assetName = assetName;
        this.assetType = assetType;
        this.currentPrice = currentPrice;
        this.percentageChange = percentageChange;
    }

    @Override
    public String toString() {
        return String.format("%-6d %-12s %-12s %12.2f %10.2f%%",
                assetId, assetName, assetType, currentPrice, percentageChange);
    }
}

// =====================================================================
// WATCHLIST — SINGLY LINKED LIST
// =====================================================================
class WatchNode {
    Asset asset;
    WatchNode next;
    WatchNode(Asset asset) { this.asset = asset; this.next = null; }
}

class Watchlist {
    private WatchNode head;

    Watchlist() { head = null; }

    // Insert at end
    void insert(Asset a) {
        WatchNode newNode = new WatchNode(a);
        if (head == null) { head = newNode; System.out.println("Added: " + a.assetName); return; }
        WatchNode temp = head;
        while (temp.next != null) temp = temp.next;
        temp.next = newNode;
        System.out.println("Added: " + a.assetName);
    }

    // Delete by asset ID
    boolean delete(int id) {
        if (head == null) { System.out.println("Watchlist is empty."); return false; }
        if (head.asset.assetId == id) {
            System.out.println("Removed: " + head.asset.assetName);
            head = head.next;
            return true;
        }
        WatchNode temp = head;
        while (temp.next != null && temp.next.asset.assetId != id) temp = temp.next;
        if (temp.next == null) { System.out.println("Asset not found in watchlist."); return false; }
        System.out.println("Removed: " + temp.next.asset.assetName);
        temp.next = temp.next.next;
        return true;
    }

    // Search by asset ID
    Asset search(int id) {
        WatchNode temp = head;
        while (temp != null) {
            if (temp.asset.assetId == id) return temp.asset;
            temp = temp.next;
        }
        return null;
    }

    // Display
    void display() {
        if (head == null) { System.out.println("Watchlist is empty."); return; }
        System.out.println("--- WATCHLIST ---");
        System.out.printf("%-6s %-12s %-12s %12s %10s%n", "ID", "Name", "Type", "Price", "Change");
        System.out.println("-------------------------------------------------------------");
        WatchNode temp = head;
        while (temp != null) {
            System.out.println(temp.asset);
            temp = temp.next;
        }
    }
}

// =====================================================================
// TRANSACTION — STACK (LIFO)
// =====================================================================
class Transaction {
    int txId;
    String type;      // BUY / SELL
    int assetId;
    int quantity;
    double price;

    Transaction(int txId, String type, int assetId, int quantity, double price) {
        this.txId = txId;
        this.type = type;
        this.assetId = assetId;
        this.quantity = quantity;
        this.price = price;
    }

    @Override
    public String toString() {
        return String.format("TX#%-4d %-5s AssetID=%-4d Qty=%-5d Price=%.2f",
                txId, type, assetId, quantity, price);
    }
}

class TransactionStack {
    private Transaction[] stack;
    private int top;
    private int capacity;

    TransactionStack(int capacity) {
        this.capacity = capacity;
        stack = new Transaction[capacity];
        top = -1;
    }

    boolean push(Transaction t) {
        if (top == capacity - 1) { System.out.println("Stack Overflow!"); return false; }
        stack[++top] = t;
        System.out.println("Pushed: " + t);
        return true;
    }

    Transaction pop() {
        if (top == -1) { System.out.println("Stack Underflow!"); return null; }
        Transaction t = stack[top--];
        System.out.println("Popped: " + t);
        return t;
    }

    Transaction peek() {
        if (top == -1) { System.out.println("Stack is empty."); return null; }
        System.out.println("Top: " + stack[top]);
        return stack[top];
    }

    void display() {
        if (top == -1) { System.out.println("No recent transactions."); return; }
        System.out.println("--- RECENT TRANSACTIONS (Top -> Bottom, LIFO) ---");
        for (int i = top; i >= 0; i--) System.out.println("  " + stack[i]);
    }
}

// =====================================================================
// ORDER — QUEUE (FIFO)
// =====================================================================
class Order {
    int orderId;
    String orderType;   // BUY / SELL
    int assetId;
    int quantity;
    double price;

    Order(int orderId, String orderType, int assetId, int quantity, double price) {
        this.orderId = orderId;
        this.orderType = orderType;
        this.assetId = assetId;
        this.quantity = quantity;
        this.price = price;
    }

    @Override
    public String toString() {
        return String.format("ORD#%-4d %-5s AssetID=%-4d Qty=%-5d Price=%.2f",
                orderId, orderType, assetId, quantity, price);
    }
}

class OrderQueue {
    private Order[] queue;
    private int front, rear, size, capacity;

    OrderQueue(int capacity) {
        this.capacity = capacity;
        queue = new Order[capacity];
        front = 0;
        rear = -1;
        size = 0;
    }

    boolean enqueue(Order o) {
        if (size == capacity) { System.out.println("Queue Overflow!"); return false; }
        rear = (rear + 1) % capacity;
        queue[rear] = o;
        size++;
        System.out.println("Enqueued: " + o);
        return true;
    }

    Order dequeue() {
        if (size == 0) { System.out.println("Queue Underflow!"); return null; }
        Order o = queue[front];
        front = (front + 1) % capacity;
        size--;
        System.out.println("Dequeued: " + o);
        return o;
    }

    Order peek() {
        if (size == 0) { System.out.println("Queue is empty."); return null; }
        System.out.println("Front: " + queue[front]);
        return queue[front];
    }

    void display() {
        if (size == 0) { System.out.println("No pending orders."); return; }
        System.out.println("--- PENDING ORDERS (Front -> Rear, FIFO) ---");
        for (int i = 0; i < size; i++) System.out.println("  " + queue[(front + i) % capacity]);
    }
}

// =====================================================================
// PORTFOLIO ITEM (for recursion)
// =====================================================================
class PortfolioItem {
    Asset asset;
    int quantity;
    PortfolioItem(Asset asset, int quantity) { this.asset = asset; this.quantity = quantity; }
}

// =====================================================================
// MAIN CLASS
// =====================================================================
public class FinTechTradingSystem {

    static Scanner sc = new Scanner(System.in);
    static Asset[] assets = new Asset[12];
    static Watchlist watchlist = new Watchlist();
    static TransactionStack txStack = new TransactionStack(20);
    static OrderQueue orderQueue = new OrderQueue(20);
    static PortfolioItem[] portfolio;
    static int txCounter = 1;
    static int orderCounter = 1;

    public static void main(String[] args) {
        initializeData();
        int choice;
        do {
            printMainMenu();
            choice = readInt("Enter your choice: ");
            switch (choice) {
                case 1: marketAssetsMenu(); break;
                case 2: searchMenu(); break;
                case 3: sortMenu(); break;
                case 4: watchlistMenu(); break;
                case 5: portfolioMenu(); break;
                case 6: transactionMenu(); break;
                case 7: orderMenu(); break;
                case 0: System.out.println("\nExiting... Goodbye!"); break;
                default: System.out.println("Invalid choice. Try again.");
            }
        } while (choice != 0);
    }

    // --------------------- INITIAL DATA -------------------------------
    static void initializeData() {
        assets[0]  = new Asset(101, "Apple",     "Stock",     189.50,  1.25);
        assets[1]  = new Asset(102, "Microsoft", "Stock",     415.30, -0.80);
        assets[2]  = new Asset(103, "Tesla",     "Stock",     245.75,  3.40);
        assets[3]  = new Asset(104, "Amazon",    "Stock",     178.90,  0.60);
        assets[4]  = new Asset(105, "Google",    "Stock",     152.20, -1.10);
        assets[5]  = new Asset(106, "Bitcoin",   "Crypto",  67500.00,  2.75);
        assets[6]  = new Asset(107, "Ethereum",  "Crypto",   3500.00, -1.95);
        assets[7]  = new Asset(108, "Gold",      "Commodity",2350.00,  0.45);
        assets[8]  = new Asset(109, "Silver",    "Commodity",  28.75, -0.35);
        assets[9]  = new Asset(110, "Oil",       "Commodity",  82.40,  1.80);
        assets[10] = new Asset(111, "Nvidia",    "Stock",     880.00,  4.20);
        assets[11] = new Asset(112, "Meta",      "Stock",     505.10, -0.55);

        portfolio = new PortfolioItem[] {
            new PortfolioItem(assets[0], 50),
            new PortfolioItem(assets[2], 20),
            new PortfolioItem(assets[6], 3),
            new PortfolioItem(assets[10], 10)
        };

        // Pre-populate transactions (LIFO demo)
        txStack.push(new Transaction(txCounter++, "BUY",  101, 50, 189.50));
        txStack.push(new Transaction(txCounter++, "BUY",  103, 20, 245.75));
        txStack.push(new Transaction(txCounter++, "SELL", 102, 15, 415.30));

        // Pre-populate orders (FIFO demo)
        orderQueue.enqueue(new Order(orderCounter++, "BUY",  104, 30, 178.90));
        orderQueue.enqueue(new Order(orderCounter++, "SELL", 105, 10, 152.20));
        orderQueue.enqueue(new Order(orderCounter++, "BUY",  111, 5,  880.00));
    }

    // ------------------------ MENUS -----------------------------------
    static void printMainMenu() {
        System.out.println("\n========== FINTECH TRADING MANAGEMENT SYSTEM ==========");
        System.out.println("1. Manage Market Assets");
        System.out.println("2. Search Asset");
        System.out.println("3. Sort Market Assets");
        System.out.println("4. Manage Watchlist");
        System.out.println("5. Calculate Portfolio Value");
        System.out.println("6. Manage Transactions");
        System.out.println("7. Manage Trading Orders");
        System.out.println("0. Exit");
        System.out.println("======================================================");
    }

    // ---------- A. MARKET ASSETS ----------
    static void marketAssetsMenu() {
        int choice;
        do {
            System.out.println("\n--- MARKET ASSETS ---");
            System.out.println("1. Display All Assets");
            System.out.println("2. Calculate Average Price");
            System.out.println("3. Find Highest-Priced Asset");
            System.out.println("4. Find Lowest-Priced Asset");
            System.out.println("0. Back to Main Menu");
            choice = readInt("Enter your choice: ");
            switch (choice) {
                case 1: displayAllAssets(); break;
                case 2: averagePrice(); break;
                case 3: highestPriced(); break;
                case 4: lowestPriced(); break;
                case 0: break;
                default: System.out.println("Invalid choice.");
            }
        } while (choice != 0);
    }

    static void displayAllAssets() {
        System.out.println("\n--- ALL MARKET ASSETS ---");
        System.out.printf("%-6s %-12s %-12s %12s %10s%n", "ID", "Name", "Type", "Price", "Change");
        System.out.println("-------------------------------------------------------------");
        for (Asset a : assets) System.out.println(a);
    }

    static void averagePrice() {
        double sum = 0;
        for (Asset a : assets) sum += a.currentPrice;
        System.out.printf("Average Price: %.2f%n", sum / assets.length);
    }

    static void highestPriced() {
        Asset max = assets[0];
        for (Asset a : assets) if (a.currentPrice > max.currentPrice) max = a;
        System.out.println("Highest-Priced Asset: " + max);
    }

    static void lowestPriced() {
        Asset min = assets[0];
        for (Asset a : assets) if (a.currentPrice < min.currentPrice) min = a;
        System.out.println("Lowest-Priced Asset: " + min);
    }

    // ---------- B. SEARCH ----------
    static void searchMenu() {
        int choice;
        do {
            System.out.println("\n--- SEARCH ASSET ---");
            System.out.println("1. Linear Search (by Asset ID)");
            System.out.println("2. Binary Search (by Asset ID)");
            System.out.println("0. Back to Main Menu");
            choice = readInt("Enter your choice: ");
            switch (choice) {
                case 1: linearSearch(readInt("Enter Asset ID to search: ")); break;
                case 2: binarySearch(readInt("Enter Asset ID to search: ")); break;
                case 0: break;
                default: System.out.println("Invalid choice.");
            }
        } while (choice != 0);
    }

    // Linear Search — O(n)
    static void linearSearch(int id) {
        for (int i = 0; i < assets.length; i++) {
            if (assets[i].assetId == id) {
                System.out.println("Found at index " + i + ": " + assets[i]);
                return;
            }
        }
        System.out.println("Asset with ID " + id + " not found.");
    }

    // Binary Search — O(log n) — requires sorted-by-ID data
    static void binarySearch(int id) {
        // Make a copy sorted by ID so binary search precondition is satisfied
        Asset[] sorted = Arrays.copyOf(assets, assets.length);
        mergeSort(sorted, 0, sorted.length - 1, 1); // field 1 = sort by ID

        int low = 0, high = sorted.length - 1;
        while (low <= high) {
            int mid = (low + high) / 2;
            System.out.println("  low=" + low + ", high=" + high + ", mid=" + mid
                    + " -> ID=" + sorted[mid].assetId);
            if (sorted[mid].assetId == id) {
                System.out.println("Found: " + sorted[mid]);
                return;
            } else if (sorted[mid].assetId < id) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        System.out.println("Asset with ID " + id + " not found.");
    }

    // ---------- C. SORT ----------
    static void sortMenu() {
        int choice;
        do {
            System.out.println("\n--- SORT MARKET ASSETS ---");
            System.out.println("1. Sort by Asset ID");
            System.out.println("2. Sort by Price");
            System.out.println("3. Sort by Percentage Change");
            System.out.println("0. Back to Main Menu");
            choice = readInt("Enter your choice: ");
            switch (choice) {
                case 1: sortByField(1); break;
                case 2: sortByField(2); break;
                case 3: sortByField(3); break;
                case 0: break;
                default: System.out.println("Invalid choice.");
            }
        } while (choice != 0);
    }

    static void sortByField(int field) {
        System.out.println("Choose sorting algorithm:");
        System.out.println("1. Bubble Sort");
        System.out.println("2. Selection Sort");
        System.out.println("3. Insertion Sort");
        System.out.println("4. Merge Sort");
        System.out.println("5. Quick Sort");
        System.out.println("0. Back");
        int algo = readInt("Enter your choice: ");
        switch (algo) {
            case 1: bubbleSort(assets, field); break;
            case 2: selectionSort(assets, field); break;
            case 3: insertionSort(assets, field); break;
            case 4: mergeSort(assets, 0, assets.length - 1, field); break;
            case 5: quickSort(assets, 0, assets.length - 1, field); break;
            case 0: return;
            default: System.out.println("Invalid choice."); return;
        }
        System.out.println("Sorted successfully.");
        displayAllAssets();
    }

    // field: 1 = Asset ID, 2 = Price, 3 = Percentage Change
    static int compareAssets(Asset a, Asset b, int field) {
        switch (field) {
            case 1: return Integer.compare(a.assetId, b.assetId);
            case 2: return Double.compare(a.currentPrice, b.currentPrice);
            case 3: return Double.compare(a.percentageChange, b.percentageChange);
            default: return 0;
        }
    }

    // --- 1. Bubble Sort ---
    static void bubbleSort(Asset[] arr, int field) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            boolean swapped = false;
            for (int j = 0; j < n - 1 - i; j++) {
                if (compareAssets(arr[j], arr[j + 1], field) > 0) {
                    Asset temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    swapped = true;
                }
            }
            if (!swapped) break; // already sorted
        }
    }

    // --- 2. Selection Sort ---
    static void selectionSort(Asset[] arr, int field) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            int minIdx = i;
            for (int j = i + 1; j < n; j++)
                if (compareAssets(arr[j], arr[minIdx], field) < 0) minIdx = j;
            Asset temp = arr[minIdx];
            arr[minIdx] = arr[i];
            arr[i] = temp;
        }
    }

    // --- 3. Insertion Sort ---
    static void insertionSort(Asset[] arr, int field) {
        int n = arr.length;
        for (int i = 1; i < n; i++) {
            Asset key = arr[i];
            int j = i - 1;
            while (j >= 0 && compareAssets(arr[j], key, field) > 0) {
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = key;
        }
    }

    // --- 4. Merge Sort ---
    static void mergeSort(Asset[] arr, int left, int right, int field) {
        if (left < right) {
            int mid = (left + right) / 2;
            mergeSort(arr, left, mid, field);        // divide left
            mergeSort(arr, mid + 1, right, field);   // divide right
            merge(arr, left, mid, right, field);     // conquer / merge
        }
    }

    static void merge(Asset[] arr, int left, int mid, int right, int field) {
        int n1 = mid - left + 1;
        int n2 = right - mid;
        Asset[] L = new Asset[n1];
        Asset[] R = new Asset[n2];
        for (int i = 0; i < n1; i++) L[i] = arr[left + i];
        for (int j = 0; j < n2; j++) R[j] = arr[mid + 1 + j];

        int i = 0, j = 0, k = left;
        while (i < n1 && j < n2) {
            if (compareAssets(L[i], R[j], field) <= 0) arr[k++] = L[i++];
            else arr[k++] = R[j++];
        }
        while (i < n1) arr[k++] = L[i++];
        while (j < n2) arr[k++] = R[j++];
    }

    // --- 5. Quick Sort (Lomuto partition) ---
    static void quickSort(Asset[] arr, int low, int high, int field) {
        if (low < high) {
            int pi = partition(arr, low, high, field);
            quickSort(arr, low, pi - 1, field);
            quickSort(arr, pi + 1, high, field);
        }
    }

    static int partition(Asset[] arr, int low, int high, int field) {
        Asset pivot = arr[high];   // Lomuto: pivot = last element
        int i = low - 1;
        for (int j = low; j < high; j++) {
            if (compareAssets(arr[j], pivot, field) <= 0) {
                i++;
                Asset temp = arr[i]; arr[i] = arr[j]; arr[j] = temp;
            }
        }
        Asset temp = arr[i + 1]; arr[i + 1] = arr[high]; arr[high] = temp;
        return i + 1;
    }

    // ---------- D. WATCHLIST ----------
    static void watchlistMenu() {
        int choice;
        do {
            System.out.println("\n--- WATCHLIST (Singly Linked List) ---");
            System.out.println("1. Insert Asset");
            System.out.println("2. Delete Asset");
            System.out.println("3. Search Asset");
            System.out.println("4. Display Watchlist");
            System.out.println("0. Back to Main Menu");
            choice = readInt("Enter your choice: ");
            switch (choice) {
                case 1: {
                    Asset a = findAssetById(readInt("Enter Asset ID to add: "));
                    if (a == null) System.out.println("Asset not found in market.");
                    else watchlist.insert(a);
                    break;
                }
                case 2: watchlist.delete(readInt("Enter Asset ID to delete: ")); break;
                case 3: {
                    Asset a = watchlist.search(readInt("Enter Asset ID to search: "));
                    if (a == null) System.out.println("Not found in watchlist.");
                    else System.out.println("Found: " + a);
                    break;
                }
                case 4: watchlist.display(); break;
                case 0: break;
                default: System.out.println("Invalid choice.");
            }
        } while (choice != 0);
    }

    static Asset findAssetById(int id) {
        for (Asset a : assets) if (a.assetId == id) return a;
        return null;
    }

    // ---------- E. PORTFOLIO (RECURSION) ----------
    static void portfolioMenu() {
        int choice;
        do {
            System.out.println("\n--- PORTFOLIO (Recursion) ---");
            System.out.println("1. Display Portfolio & Total Value (Recursive)");
            System.out.println("0. Back to Main Menu");
            choice = readInt("Enter your choice: ");
            switch (choice) {
                case 1:
                    System.out.println("\n--- PORTFOLIO ---");
                    System.out.printf("%-12s %-10s %-12s %-12s%n", "Asset", "Qty", "Price", "Value");
                    System.out.println("-------------------------------------------------");
                    displayPortfolioRecursive(portfolio, 0);
                    double total = portfolioValueRecursive(portfolio, 0);
                    System.out.printf("%nTOTAL PORTFOLIO VALUE: %.2f%n", total);
                    break;
                case 0: break;
                default: System.out.println("Invalid choice.");
            }
        } while (choice != 0);
    }

    /**
     * Recursive total-portfolio-value computation.
     * BASE CASE       : index == items.length  ->  return 0
     * RECURSIVE CASE  : current item value + recursive call on index + 1
     */
    static double portfolioValueRecursive(PortfolioItem[] items, int index) {
        if (index == items.length) return 0.0;                            // BASE CASE
        double currentValue = items[index].asset.currentPrice
                            * items[index].quantity;
        return currentValue + portfolioValueRecursive(items, index + 1); // RECURSIVE CASE
    }

    /**
     * Recursive portfolio display.
     * BASE CASE       : index == items.length  ->  stop
     * RECURSIVE CASE  : print current item, then recurse on index + 1
     */
    static void displayPortfolioRecursive(PortfolioItem[] items, int index) {
        if (index == items.length) return;                                // BASE CASE
        PortfolioItem it = items[index];
        System.out.printf("%-12s %-10d %-12.2f %-12.2f%n",
                it.asset.assetName, it.quantity, it.asset.currentPrice,
                it.asset.currentPrice * it.quantity);
        displayPortfolioRecursive(items, index + 1);                      // RECURSIVE CASE
    }

    // ---------- F. TRANSACTIONS (STACK - LIFO) ----------
    static void transactionMenu() {
        int choice;
        do {
            System.out.println("\n--- RECENT TRANSACTIONS (Stack - LIFO) ---");
            System.out.println("1. Push Transaction");
            System.out.println("2. Pop Transaction");
            System.out.println("3. Peek Transaction");
            System.out.println("4. Display All Transactions");
            System.out.println("0. Back to Main Menu");
            choice = readInt("Enter your choice: ");
            switch (choice) {
                case 1: {
                    Asset a = findAssetById(readInt("Enter Asset ID: "));
                    if (a == null) { System.out.println("Asset not found."); break; }
                    System.out.print("Enter type (BUY/SELL): ");
                    String type = sc.next().toUpperCase();
                    int qty = readInt("Enter quantity: ");
                    txStack.push(new Transaction(txCounter++, type, a.assetId, qty, a.currentPrice));
                    break;
                }
                case 2: txStack.pop(); break;
                case 3: txStack.peek(); break;
                case 4: txStack.display(); break;
                case 0: break;
                default: System.out.println("Invalid choice.");
            }
        } while (choice != 0);
    }

    // ---------- G. ORDERS (QUEUE - FIFO) ----------
    static void orderMenu() {
        int choice;
        do {
            System.out.println("\n--- TRADING ORDERS (Queue - FIFO) ---");
            System.out.println("1. Enqueue Order");
            System.out.println("2. Dequeue Order");
            System.out.println("3. Peek Order");
            System.out.println("4. Display All Orders");
            System.out.println("0. Back to Main Menu");
            choice = readInt("Enter your choice: ");
            switch (choice) {
                case 1: {
                    Asset a = findAssetById(readInt("Enter Asset ID: "));
                    if (a == null) { System.out.println("Asset not found."); break; }
                    System.out.print("Enter order type (BUY/SELL): ");
                    String type = sc.next().toUpperCase();
                    int qty = readInt("Enter quantity: ");
                    orderQueue.enqueue(new Order(orderCounter++, type, a.assetId, qty, a.currentPrice));
                    break;
                }
                case 2: orderQueue.dequeue(); break;
                case 3: orderQueue.peek(); break;
                case 4: orderQueue.display(); break;
                case 0: break;
                default: System.out.println("Invalid choice.");
            }
        } while (choice != 0);
    }

    // ---------------------- UTILITY -----------------------------------
    static int readInt(String prompt) {
        System.out.print(prompt);
        while (!sc.hasNextInt()) {
            System.out.print("Invalid input. " + prompt);
            sc.next();
        }
        int v = sc.nextInt();
        sc.nextLine(); // consume newline
        return v;
    }
}