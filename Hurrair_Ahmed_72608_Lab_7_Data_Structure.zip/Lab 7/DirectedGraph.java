/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.data_structure;

/**
 *
 * @author pc
 */
public class DirectedGraph {

    static class directedGraph {
        private int[][] adj;
        private int vertices;

        public directedGraph(int vertices) {
            this.vertices = vertices;
            adj = new int[vertices][vertices];
        }

        // Directed edge: u -> v
        public void addEdge(int u, int v) {
            if (u >= 0 && u < vertices && v >= 0 && v < vertices) {
                adj[u][v] = 1;
            }
        }

        public void displayMatrix() {
            System.out.print("   ");
            for (int i = 0; i < vertices; i++) {
                System.out.printf("%3d", i);
            }
            System.out.println();

            for (int i = 0; i < vertices; i++) {
                System.out.printf("%2d ", i);
                for (int j = 0; j < vertices; j++) {
                    System.out.printf("%3d", adj[i][j]);
                }
                System.out.println();
            }
        }

        // Out-degree = number of 1s in row
        public int outDegree(int v) {
            int degree = 0;
            for (int j = 0; j < vertices; j++) {
                degree += adj[v][j];
            }
            return degree;
        }

        // In-degree = number of 1s in column
        public int inDegree(int v) {
            int degree = 0;
            for (int i = 0; i < vertices; i++) {
                degree += adj[i][v];
            }
            return degree;
        }
    }

    public static void main(String[] args) {
        directedGraph g = new directedGraph(5);

        g.addEdge(0, 1);
        g.addEdge(0, 2);
        g.addEdge(1, 2);
        g.addEdge(2, 3);
        g.addEdge(3, 1);

        System.out.println("Adjacency Matrix of Directed Graph:");
        g.displayMatrix();

        System.out.println("\nVertex\tIn-Degree\tOut-Degree");
        for (int i = 0; i < 5; i++) {
            System.out.println(i + "\t" + g.inDegree(i) + "\t\t" + g.outDegree(i));
        }
    }
}
