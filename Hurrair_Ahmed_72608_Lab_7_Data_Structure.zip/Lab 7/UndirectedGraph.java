/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.data_structure;

/**
 *
 * @author pc
 */
public class UndirectedGraph {
    static class Graph {
        private int[][] adj;
        private int vertices;
        public Graph(int vertices) {
            this.vertices = vertices;
            adj = new int[vertices][vertices];
        }
        public void addEdge(int u, int v) {
            if (u >= 0 && u < vertices && v >= 0 && v < vertices) {
                adj[u][v] = 1;
                adj[v][u] = 1;
            }
        }
        public void displayMatrix() {
            System.out.print("   ");
            for (int i = 0; i < vertices; i++) {
                System.out.printf("%3d", i);
            }
            System.out.println();

            for (int i = 0; i < vertices; i++) {
                System.out.printf("%2d ", i);
                for (int j = 0; j < vertices; j++) {
                    System.out.printf("%3d", adj[i][j]);
                }
                System.out.println();
            }
        }

        public int degree(int v) {
            int degree = 0;
            for (int j = 0; j < vertices; j++) {
                degree += adj[v][j];
            }
            return degree;
        }
    }

    public static void main(String[] args) {
        Graph g = new Graph(5);

        g.addEdge(0, 1);
        g.addEdge(0, 2);
        g.addEdge(1, 2);
        g.addEdge(1, 3);
        g.addEdge(3, 4);

        System.out.println("Adjacency Matrix of Undirected Graph:");
        g.displayMatrix();

        System.out.println("\nDegrees of vertices:");
        for (int i = 0; i < 5; i++) {
            System.out.println("Degree of vertex " + i + ": " + g.degree(i));
        }
    }
}