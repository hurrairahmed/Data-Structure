/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.data_structure;
    import java.util.Scanner;

/**
 *
 * @author pc
 */
public class UniGraph {


    static class CommunicationGraph {
        private int[][] adj;
        private int vertices;

        public CommunicationGraph(int vertices) {
            this.vertices = vertices;
            adj = new int[vertices][vertices];
        }

        // Communication links are bidirectional
        public void addLink(int u, int v) {
            if (u >= 0 && u < vertices && v >= 0 && v < vertices && u != v) {
                adj[u][v] = 1;
                adj[v][u] = 1;
            } else {
                System.out.println("Invalid department number. Link ignored.");
            }
        }

        public boolean isDirectlyConnected(int u, int v) {
            if (u >= 0 && u < vertices && v >= 0 && v < vertices) {
                return adj[u][v] == 1;
            }
            return false;
        }

        public int degree(int v) {
            int degree = 0;
            for (int j = 0; j < vertices; j++) {
                degree += adj[v][j];
            }
            return degree;
        }

        public void displayMatrix() {
            System.out.print("   ");
            for (int i = 0; i < vertices; i++) {
                System.out.printf("%3d", i);
            }
            System.out.println();

            for (int i = 0; i < vertices; i++) {
                System.out.printf("%2d ", i);
                for (int j = 0; j < vertices; j++) {
                    System.out.printf("%3d", adj[i][j]);
                }
                System.out.println();
            }
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        final int DEPARTMENTS = 5;

        CommunicationGraph graph = new CommunicationGraph(DEPARTMENTS);

        System.out.print("Enter number of communication links: ");
        int links = sc.nextInt();

        System.out.println("Enter each link as two department numbers (0-4):");
        for (int i = 0; i < links; i++) {
            int a = sc.nextInt();
            int b = sc.nextInt();
            graph.addLink(a, b);
        }

        int choice;
        do {
            System.out.println("\n--- University Communication Graph Menu ---");
            System.out.println("1. Display adjacency matrix");
            System.out.println("2. Check if two departments are directly connected");
            System.out.println("3. Display degree of a department");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    graph.displayMatrix();
                    break;

                case 2:
                    System.out.print("Enter first department: ");
                    int u = sc.nextInt();
                    System.out.print("Enter second department: ");
                    int v = sc.nextInt();

                    if (graph.isDirectlyConnected(u, v)) {
                        System.out.println("Departments " + u + " and " + v + " are directly connected.");
                    } else {
                        System.out.println("Departments " + u + " and " + v + " are NOT directly connected.");
                    }
                    break;

                case 3:
                    System.out.print("Enter department number: ");
                    int d = sc.nextInt();
                    System.out.println("Degree of department " + d + ": " + graph.degree(d));
                    break;

                case 4:
                    System.out.println("Exiting program.");
                    break;

                default:
                    System.out.println("Invalid choice.");
            }
        } while (choice != 4);

        sc.close();
    }
}
