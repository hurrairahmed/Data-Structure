/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.data_structure;
    import java.util.Scanner;

/**
 *
 * @author pc
 */

class Student {
    int id;
    String name;
    Student(int id, String name) { this.id = id; this.name = name; }
    public String toString() { return "ID: " + id + ", Name: " + name; }
}

class StudentNode {
    Student student;
    StudentNode left, right;
    StudentNode(Student student) { this.student = student; left = null; right = null; }
}

class StudentBST {
    StudentNode root;
    StudentBST() { root = null; }

    // Insert
    void insert(int id, String name) {
        root = insertRecursive(root, new Student(id, name));
    }

    StudentNode insertRecursive(StudentNode current, Student student) {
        if (current == null) return new StudentNode(student);
        if (student.id < current.student.id)
            current.left = insertRecursive(current.left, student);
        else if (student.id > current.student.id)
            current.right = insertRecursive(current.right, student);
        else
            System.out.println("Duplicate ID " + student.id + " — record not inserted.");
        return current;
    }

    // Search
    Student search(int id) {
        StudentNode current = root;
        while (current != null) {
            if (id == current.student.id) return current.student;
            current = (id < current.student.id) ? current.left : current.right;
        }
        return null;
    }

    // Delete
    void delete(int id) { root = deleteRecursive(root, id); }

    StudentNode deleteRecursive(StudentNode current, int id) {
        if (current == null) return null;

        if (id < current.student.id) {
            current.left = deleteRecursive(current.left, id);
        } else if (id > current.student.id) {
            current.right = deleteRecursive(current.right, id);
        } else {
            // Case 1: leaf
            if (current.left == null && current.right == null) return null;
            // Case 2: one child
            if (current.left == null)  return current.right;
            if (current.right == null) return current.left;
            // Case 3: two children
            StudentNode successor = findMinNode(current.right);
            current.student = successor.student;
            current.right = deleteRecursive(current.right, successor.student.id);
        }
        return current;
    }

    StudentNode findMinNode(StudentNode current) {
        while (current.left != null) current = current.left;
        return current;
    }

    // Display ascending ID (inorder)
    void displayInorder() { displayInorderRecursive(root); }

    void displayInorderRecursive(StudentNode current) {
        if (current == null) return;
        displayInorderRecursive(current.left);
        System.out.println(current.student);
        displayInorderRecursive(current.right);
    }

    // Count
    int count() { return countRecursive(root); }

    int countRecursive(StudentNode current) {
        if (current == null) return 0;
        return 1 + countRecursive(current.left) + countRecursive(current.right);
    }
}

public class Lab_8_Task_3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        StudentBST bst = new StudentBST();
        int choice;

        do {
            System.out.println("\n===== Student Record Management =====");
            System.out.println("1. Insert student");
            System.out.println("2. Search student by ID");
            System.out.println("3. Delete student by ID");
            System.out.println("4. Display all records (ascending ID)");
            System.out.println("5. Show total number of students");
            System.out.println("0. Exit");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();
            sc.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter Student ID: ");
                    int id = sc.nextInt(); sc.nextLine();
                    System.out.print("Enter Student Name: ");
                    String name = sc.nextLine();
                    bst.insert(id, name);
                    System.out.println("Student inserted.");
                    break;
                case 2:
                    System.out.print("Enter ID to search: ");
                    Student s = bst.search(sc.nextInt());
                    System.out.println(s != null ? "Found → " + s : "Student not found.");
                    break;
                case 3:
                    System.out.print("Enter ID to delete: ");
                    bst.delete(sc.nextInt());
                    System.out.println("Deletion completed (if ID existed).");
                    break;
                case 4:
                    System.out.println("--- Student Records (ascending ID) ---");
                    bst.displayInorder();
                    break;
                case 5:
                    System.out.println("Total students: " + bst.count());
                    break;
                case 0:
                    System.out.println("Exiting program.");
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        } while (choice != 0);

        sc.close();
    }
}