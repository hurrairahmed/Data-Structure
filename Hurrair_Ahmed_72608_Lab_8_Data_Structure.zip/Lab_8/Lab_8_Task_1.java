/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.data_structure;

/**
 *
 * @author pc
 */
    class Node {
    int data;
    Node left, right;
    Node(int value) { data = value; left = null; right = null; }
}

class BinarySearchTree {
    Node root;
    BinarySearchTree() { root = null; }

    void insert(int value) { root = insertRecursive(root, value); }

    Node insertRecursive(Node current, int value) {
        if (current == null) return new Node(value);
        if (value < current.data)       current.left  = insertRecursive(current.left, value);
        else if (value > current.data)  current.right = insertRecursive(current.right, value);
        return current;
    }

    void inorder(Node current) {
        if (current == null) return;
        inorder(current.left);
        System.out.print(current.data + " ");
        inorder(current.right);
    }

    void preorder(Node current) {
        if (current == null) return;
        System.out.print(current.data + " ");
        preorder(current.left);
        preorder(current.right);
    }

    void postorder(Node current) {
        if (current == null) return;
        postorder(current.left);
        postorder(current.right);
        System.out.print(current.data + " ");
    }

    int findMin() {
        if (root == null) throw new IllegalArgumentException("Tree is empty");
        Node current = root;
        while (current.left != null) current = current.left;
        return current.data;
    }

    int findMax() {
        if (root == null) throw new IllegalArgumentException("Tree is empty");
        Node current = root;
        while (current.right != null) current = current.right;
        return current.data;
    }
}

public class Lab_8_Task_1 {
    public static void main(String[] args) {
        BinarySearchTree bst = new BinarySearchTree();
        int[] values = {45, 25, 65, 15, 35, 55, 75, 10, 20};
        for (int v : values) bst.insert(v);

        System.out.print("Inorder:   "); bst.inorder(bst.root);   System.out.println();
        System.out.print("Preorder:  "); bst.preorder(bst.root);  System.out.println();
        System.out.print("Postorder: "); bst.postorder(bst.root); System.out.println();
        System.out.println("Minimum: " + bst.findMin());
        System.out.println("Maximum: " + bst.findMax());
    }
}
