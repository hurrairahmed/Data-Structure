/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.data_structure;

/**
 *
 * @author pc
 */
    class Node {
    int data;
    Node left, right;
    Node(int value) { data = value; left = null; right = null; }
}

class BinarySearchTree {
    Node root;
    BinarySearchTree() { root = null; }

    void insert(int value) { root = insertRecursive(root, value); }

    Node insertRecursive(Node current, int value) {
        if (current == null) return new Node(value);
        if (value < current.data)       current.left  = insertRecursive(current.left, value);
        else if (value > current.data)  current.right = insertRecursive(current.right, value);
        return current;
    }

    boolean search(int value) { return searchRecursive(root, value); }

    boolean searchRecursive(Node current, int value) {
        if (current == null)        return false;
        if (current.data == value)  return true;
        if (value < current.data)   return searchRecursive(current.left, value);
        return searchRecursive(current.right, value);
    }

    void inorder(Node current) {
        if (current == null) return;
        inorder(current.left);
        System.out.print(current.data + " ");
        inorder(current.right);
    }

    void delete(int value) { root = deleteRecursive(root, value); }

    Node deleteRecursive(Node current, int value) {
        if (current == null) return null;

        if (value < current.data) {
            current.left = deleteRecursive(current.left, value);
        } else if (value > current.data) {
            current.right = deleteRecursive(current.right, value);
        } else {
            // Case 1: no child
            if (current.left == null && current.right == null) return null;
            // Case 2: one child
            if (current.left == null)  return current.right;
            if (current.right == null) return current.left;
            // Case 3: two children
            current.data = findMinValue(current.right);
            current.right = deleteRecursive(current.right, current.data);
        }
        return current;
    }

    int findMinValue(Node current) {
        while (current.left != null) current = current.left;
        return current.data;
    }
}

public class Lab_8_Task_2 {
    public static void main(String[] args) {
        BinarySearchTree bst = new BinarySearchTree();
        int[] values = {45, 25, 65, 15, 35, 55, 75, 10, 20};
        for (int v : values) bst.insert(v);

        System.out.println("Search 35:  " + bst.search(35));
        System.out.println("Search 100: " + bst.search(100));

        bst.delete(10);
        System.out.print("Inorder after deleting 10: "); bst.inorder(bst.root); System.out.println();

        bst.delete(25);
        System.out.print("Inorder after deleting 25: "); bst.inorder(bst.root); System.out.println();

        bst.delete(45);
        System.out.print("Inorder after deleting 45: "); bst.inorder(bst.root); System.out.println();
    }
}
