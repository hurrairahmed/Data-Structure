/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab_02;
import java.util.Scanner;

/**
 *
 * @author pc
 */
public class Lab_3 {
    public static void main(String[] args) {
//        Scanner input = new Scanner(System.in);
//
//        System.out.print("Enter a non-negative integer for factorial: ");
//        int n = input.nextInt();
//
//        if (n < 0) {
//            System.out.println("Factorial is not defined for negative numbers.");
//        } else {
//            System.out.println("Factorial of " + n + " = " + factorial(n));
//        }
//
//        int[] arr = {12, 45, 7, 23, 56, 89, 34};
//
//        System.out.print("Array elements: ");
//        printRecursive(arr, 0);
//        System.out.println();
//
//        System.out.println("Sum = " + sumRecursive(arr, 0));
//
//        System.out.print("Enter target value to search: ");
//        int target = input.nextInt();
//
//        int index = searchRecursive(arr, target, 0);
//
//        if (index == -1) {
//            System.out.println(target + " not found.");
//        } else {
//            System.out.println(target + " found at index " + index + ".");
//        }
//
//        input.close();
//    }
//
//    public static long factorial(int n) {
//        if (n == 0 || n == 1) {
//            return 1;
//        }
//
//        return n * factorial(n - 1);
//    }
//
//    public static void printRecursive(int[] arr, int index) {
//        if (index == arr.length) {
//            return;
//        }
//
//        System.out.print(arr[index] + " ");
//        printRecursive(arr, index + 1);
//    }
//
//    public static int sumRecursive(int[] arr, int index) {
//        if (index == arr.length) {
//            return 0;
//        }
//
//        return arr[index] + sumRecursive(arr, index + 1);
//    }
//
//    public static int searchRecursive(int[] arr, int target, int index) {
//        if (index == arr.length) {
//            return -1;
//        }
//
//        if (arr[index] == target) {
//            return index;
//        }
//
//        return searchRecursive(arr, target, index + 1);
//    }

        int[] arrayForMerge = {64, 25, 12, 22, 11, 90, 34};
        int[] arrayForQuick = {64, 25, 12, 22, 11, 90, 34};

        System.out.println("    ");
        System.out.println("RUNNING  SORT DEMO");
        System.out.println("    ");

        System.out.print("Initial State: ");
        printFullArray(arrayForMerge);

        System.out.println("\n");

        mergeSort(arrayForMerge, 0, arrayForMerge.length - 1);

        System.out.print("\nFinal Sorted Array (Merge Sort): ");
        printFullArray(arrayForMerge);
        System.out.println();

        System.out.println(" ");
        System.out.println("RUNNING QUICK SORT DEMO");
        System.out.println(" ");

        System.out.print("Initial State: ");
        printFullArray(arrayForQuick);

        System.out.println("\n");

        quickSort(arrayForQuick, 0, arrayForQuick.length - 1);

        System.out.print("\nFinal Sorted Array (Quick Sort): ");
        printFullArray(arrayForQuick);
        System.out.println();
    }
    
    public static void mergeSort(int[] arr, int left, int right) {
        if (left < right) {
            int mid = left + (right - left) / 2;

            System.out.print("Splitting subarray: ");
            printSubarray(arr, left, right);
            System.out.println();

            mergeSort(arr, left, mid);
            mergeSort(arr, mid + 1, right);

            merge(arr, left, mid, right);
        }
    }

    private static void merge(int[] arr, int left, int mid, int right) {
        int n1 = mid - left + 1;
        int n2 = right - mid;

        int[] L = new int[n1];
        int[] R = new int[n2];


        for (int i = 0; i < n1; i++) {
            L[i] = arr[left + i];
        }

        for (int j = 0; j < n2; j++) {
            R[j] = arr[mid + 1 + j];
        }

        System.out.print(" Merging parts -> Left: ");
        printInline(L);

        System.out.print(" and Right: ");
        printInline(R);
        System.out.println();

        int i = 0, j = 0, k = left;
        
        while (i < n1 && j < n2) {
            if (L[i] <= R[j]) {
                arr[k] = L[i];
                i++;
            } else {
                arr[k] = R[j];
                j++;
            }
            k++;
        }
        while (i < n1) {
            arr[k] = L[i];
            i++;
            k++;
        }

        while (j < n2) {
            arr[k] = R[j];
            j++;
            k++;
        }

        System.out.print(" Result after merge phase: ");
        printSubarray(arr, left, right);
        System.out.println();
    }

    public static void quickSort(int[] arr, int low, int high) {
        if (low < high) {
            System.out.print("Processing index range: ");
            printSubarray(arr, low, high);
            System.out.println();

            int pi = partition(arr, low, high);

            quickSort(arr, low, pi - 1);
            quickSort(arr, pi + 1, high);
        }
    }

    private static int partition(int[] arr, int low, int high) {
        int pivot = arr[high];
        System.out.println(" Selected Pivot Value: [" + pivot + "]");

        int i = low - 1;

        for (int j = low; j < high; j++) {
            if (arr[j] <= pivot) {
                i++;

                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }

        int temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;

        System.out.print(" Current Array State after Partition: ");
        printFullArray(arr);
        System.out.println();

        System.out.println(" Pivot element locked at index location: " + (i + 1));

        return i + 1;
    }

    private static void printFullArray(int[] arr) {
        for (int val : arr) {
            System.out.print(val + " ");
        }
        System.out.println();
    }

    private static void printInline(int[] arr) {
        for (int val : arr) {
            System.out.print(val + " ");
        }
    }

    private static void printSubarray(int[] arr, int left, int right) {
        for (int i = left; i <= right; i++) {
            System.out.print(arr[i] + " ");
        }
    }
}
    