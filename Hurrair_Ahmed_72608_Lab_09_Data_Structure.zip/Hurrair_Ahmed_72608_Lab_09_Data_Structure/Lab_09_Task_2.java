/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.data_structure;

/**
 *
 * @author pc
 */
class HashEntry {
    int key; String value; boolean isDeleted;
    HashEntry(int k, String v) { key = k; value = v; isDeleted = false; }
}

class ProbingTable {
    private HashEntry[] table;
    private int size, count;

    ProbingTable(int size) {
        this.size = size;
        this.table = new HashEntry[size];
        this.count = 0;
    }

    private int h1(int key) { return Math.abs(key) % size; }
    private int h2(int key) { return 7 - (Math.abs(key) % 7); }   // for Task 2

    private int probeIndex(int key, int i, String mode) {
        if (mode.equals("QUADRATIC"))
            return (h1(key) + i * i) % size;
        else                                              // DOUBLE
            return (h1(key) + i * h2(key)) % size;
    }

    // returns number of probe steps used
    int insert(int key, String value, String mode) {
        if (count == size) { System.out.println("Table full!"); return -1; }
        for (int i = 0; i < size; i++) {
            int idx = probeIndex(key, i, mode);
            if (table[idx] == null) {
                table[idx] = new HashEntry(key, value);
                count++;
                return i + 1;                              // probes used
            }
        }
        return -1;
    }

    void display() {
        for (int i = 0; i < size; i++) {
            if (table[i] == null)
                System.out.println("    Slot " + i + " : [EMPTY]");
            else
                System.out.println("    Slot " + i + " : " + table[i].key);
        }
    }
}

public class Lab_09_Task_2 {
    public static void main(String[] args) {
        int[] keys = {22, 33, 44, 11, 55};

        // ---------------- Quadratic ----------------
        System.out.println("===== Quadratic Probing (size 11) =====\n");
        ProbingTable q = new ProbingTable(11);
        int qTotal = 0;
        for (int k : keys) {
            int p = q.insert(k, "Val_" + k, "QUADRATIC");
            System.out.println("Insert " + k + " -> probes = " + p);
            qTotal += p;
        }
        System.out.println("\nQuadratic final table:");
        q.display();
        System.out.println("Total quadratic probes = " + qTotal);

        // ---------------- Double Hashing ----------------
        System.out.println("\n===== Double Hashing (size 11, h2(k)=7-(k%7)) =====\n");
        ProbingTable d = new ProbingTable(11);
        int dTotal = 0;
        for (int k : keys) {
            int p = d.insert(k, "Val_" + k, "DOUBLE");
            System.out.println("Insert " + k + " -> probes = " + p);
            dTotal += p;
        }
        System.out.println("\nDouble hashing final table:");
        d.display();
        System.out.println("Total double-hashing probes = " + dTotal);

        // ---------------- Comparison ----------------
        System.out.println("\n===== Comparison =====");
        System.out.println("Quadratic probes : " + qTotal);
        System.out.println("Double    probes : " + dTotal);
        if (dTotal < qTotal)
            System.out.println("=> Double Hashing used FEWER probe steps.");
        else if (dTotal > qTotal)
            System.out.println("=> Quadratic Probing used FEWER probe steps.");
        else
            System.out.println("=> Both used the SAME number of probe steps.");
    }
}