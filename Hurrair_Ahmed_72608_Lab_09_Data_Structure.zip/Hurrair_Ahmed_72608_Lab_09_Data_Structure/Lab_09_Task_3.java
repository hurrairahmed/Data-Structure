/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.data_structure;

/**
 *
 * @author pc
 */
class HashEntry {
    int key; String value; boolean isDeleted;
    HashEntry(int k, String v) { key = k; value = v; isDeleted = false; }
}

class DoubleHashTable {
    private HashEntry[] table;
    private int size, count;

    DoubleHashTable(int size) {
        this.size = size;
        this.table = new HashEntry[size];
        this.count = 0;
    }

    private int h1(int key) { return Math.abs(key) % size; }
    private int h2(int key) { return 5 - (Math.abs(key) % 5); }

    private int probeIndex(int key, int i) {
        return (h1(key) + i * h2(key)) % size;
    }

    void insert(int key, String value) {
        if (count == size) { System.out.println("Table full!"); return; }
        for (int i = 0; i < size; i++) {
            int idx = probeIndex(key, i);
            if (table[idx] == null || table[idx].isDeleted) {
                table[idx] = new HashEntry(key, value);
                count++;
                return;
            } else if (table[idx].key == key) {
                table[idx].value = value;
                return;
            }
        }
    }

    String search(int key) {
        for (int i = 0; i < size; i++) {
            int idx = probeIndex(key, i);
            if (table[idx] == null) return null;
            if (!table[idx].isDeleted && table[idx].key == key)
                return table[idx].value;
        }
        return null;
    }

    boolean delete(int key) {
        for (int i = 0; i < size; i++) {
            int idx = probeIndex(key, i);
            if (table[idx] == null) return false;
            if (!table[idx].isDeleted && table[idx].key == key) {
                table[idx].isDeleted = true;      // TOMBSTONE
                count--;
                return true;
            }
        }
        return false;
    }

    void display() {
        for (int i = 0; i < size; i++) {
            if (table[i] == null)
                System.out.println("    Slot " + i + " : [EMPTY]");
            else if (table[i].isDeleted)
                System.out.println("    Slot " + i + " : [DELETED]");
            else
                System.out.println("    Slot " + i + " : (" + table[i].key
                        + ", \"" + table[i].value + "\")");
        }
    }
}

public class Lab_09_Task_3 {
    public static void main(String[] args) {
        System.out.println("===== TASK 3: Double Hashing + Tombstone Delete =====\n");
        DoubleHashTable ht = new DoubleHashTable(7);

        int[]    k = {12, 19, 26, 5};
        String[] v = {"Ali", "Sara", "Bilal", "Hina"};
        for (int i = 0; i < k.length; i++) {
            ht.insert(k[i], v[i]);
            System.out.println("Inserted (" + k[i] + ", \"" + v[i] + "\")");
        }

        System.out.println("\n--- Table after all insertions ---");
        ht.display();

        System.out.println("\n--- Deleting key 19 ---");
        boolean ok = ht.delete(19);
        System.out.println("Delete 19 returned: " + ok);
        System.out.println("\n--- Table after delete (tombstone at slot 6) ---");
        ht.display();

        System.out.println("\n--- Search for key 26 after deleting 19 ---");
        String got = ht.search(26);
        System.out.println("Result: " + (got != null ? "FOUND (\"" + got + "\")" : "NOT FOUND"));
    }
}