/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.data_structure;

/**
 *
 * @author pc
 */
    class HashEntry {
    int key; String value; boolean isDeleted;
    HashEntry(int k, String v) { key = k; value = v; isDeleted = false; }
}

class LinearHashTable {
    private HashEntry[] table;
    private int size, count;

    LinearHashTable(int size) {
        this.size = size;
        this.table = new HashEntry[size];
        this.count = 0;
    }

    private int h(int key) { return Math.abs(key) % size; }

    // returns number of collisions while inserting this key
    int insert(int key, String value) {
        if (count == size) { System.out.println("Table full!"); return -1; }
        int collisions = 0;
        for (int i = 0; i < size; i++) {
            int idx = (h(key) + i) % size;          // Linear probing
            if (table[idx] == null) {
                table[idx] = new HashEntry(key, value);
                count++;
                return collisions;
            } else if (table[idx].key == key) {
                table[idx].value = value;           // update
                return collisions;
            }
            collisions++;                            // slot occupied by another key
        }
        return collisions;
    }

    String search(int key) {
        for (int i = 0; i < size; i++) {
            int idx = (h(key) + i) % size;
            if (table[idx] == null) return null;
            if (table[idx].key == key) return table[idx].value;
        }
        return null;
    }

    void display() {
        System.out.println("  Index : Value");
        for (int i = 0; i < size; i++) {
            if (table[i] == null)
                System.out.println("    " + i + "   : [EMPTY]");
            else
                System.out.println("    " + i + "   : " + table[i].key);
        }
    }
}

public class Lab_09_Task_1 {
    public static void main(String[] args) {
        System.out.println("===== TASK 1: Linear Probing (size 7, h(k)=k%7) =====\n");
        LinearHashTable ht = new LinearHashTable(7);
        int[] keys = {14, 21, 8, 15, 22};
        int totalCollisions = 0;

        for (int k : keys) {
            int c = ht.insert(k, "Val_" + k);
            System.out.println("Insert " + k + " -> collisions this insert = " + c);
            totalCollisions += c;
        }

        System.out.println("\nFinal Table:");
        ht.display();
        System.out.println("\nTotal collisions = " + totalCollisions);

        String s15 = ht.search(15);
        String s99 = ht.search(99);
        System.out.println("\nSearch 15 : " + (s15 != null ? "FOUND (" + s15 + ")" : "NOT FOUND"));
        System.out.println("Search 99 : " + (s99 != null ? "FOUND (" + s99 + ")" : "NOT FOUND"));
    }
}

