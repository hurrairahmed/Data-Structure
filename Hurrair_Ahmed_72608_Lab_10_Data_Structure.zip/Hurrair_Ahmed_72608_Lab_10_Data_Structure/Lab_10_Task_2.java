/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.data_structure;

/**
 *
 * @author pc
 */
class MaxHeap {
    int[] heap;
    int size;
    int capacity;

    MaxHeap(int capacity) {
        this.capacity = capacity;
        this.heap = new int[capacity];
        this.size = 0;
    }

    int parent(int i)     { return (i - 1) / 2; }
    int leftChild(int i)  { return 2 * i + 1; }
    int rightChild(int i) { return 2 * i + 2; }

    void swap(int i, int j) {
        int t = heap[i]; heap[i] = heap[j]; heap[j] = t;
    }

    // ---- Insertion (Heapify-Up) ----
    void insert(int value) {
        if (size == capacity) { System.out.println("Max Heap is full!"); return; }
        heap[size] = value;
        int current = size;
        size++;
        while (current > 0 && heap[current] > heap[parent(current)]) {
            swap(current, parent(current));
            current = parent(current);
        }
    }

    // ---- Peek ----
    int peek() {
        if (size == 0) throw new IllegalStateException("Max Heap is empty");
        return heap[0];
    }

    // ---- Extract Max (Heapify-Down) ----
    int extractMax() {
        if (size == 0) throw new IllegalStateException("Max Heap is empty");
        int max = heap[0];
        heap[0] = heap[size - 1];
        size--;
        heapifyDown(0);
        return max;
    }

    void heapifyDown(int i) {
        int largest = i;
        int left  = leftChild(i);
        int right = rightChild(i);
        if (left  < size && heap[left]  > heap[largest]) largest = left;
        if (right < size && heap[right] > heap[largest]) largest = right;
        if (largest != i) { swap(i, largest); heapifyDown(largest); }
    }

    void display() {
        if (size == 0) { System.out.println("Heap is empty."); return; }
        System.out.print("[ ");
        for (int i = 0; i < size; i++) System.out.print(heap[i] + " ");
        System.out.println("]");
    }
}

public class Lab_10_Task_2 {
    public static void main(String[] args) {
        System.out.println("===== TASK 2: Max Heap & Top 3 Quiz Scores =====\n");

        MaxHeap mh = new MaxHeap(20);
        int[] scores = {65, 92, 78, 85, 99, 70, 88};

        System.out.print("Inserting quiz scores : ");
        for (int s : scores) System.out.print(s + " ");
        System.out.println("\n");

        for (int s : scores) mh.insert(s);

        System.out.print("Max Heap after insertions : ");
        mh.display();
        System.out.println("Highest score (peek)      : " + mh.peek());

        System.out.println("\n--- Extracting Top 3 Highest Scores ---");
        int first  = mh.extractMax();
        int second = mh.extractMax();
        int third  = mh.extractMax();
        System.out.println("1st Highest : " + first);
        System.out.println("2nd Highest : " + second);
        System.out.println("3rd Highest : " + third);

        System.out.print("\nRemaining elements after removing Top 3 : ");
        mh.display();
    }
}