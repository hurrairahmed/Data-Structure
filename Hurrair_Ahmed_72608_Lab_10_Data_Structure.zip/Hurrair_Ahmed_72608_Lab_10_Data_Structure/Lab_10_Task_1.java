/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.data_structure;

/**
 *
 * @author pc
 */
class MinHeap {
    int[] heap;
    int size;
    int capacity;

    MinHeap(int capacity) {
        this.capacity = capacity;
        this.heap = new int[capacity];
        this.size = 0;
    }

    int parent(int i)     { return (i - 1) / 2; }
    int leftChild(int i)  { return 2 * i + 1; }
    int rightChild(int i) { return 2 * i + 2; }

    void swap(int i, int j) {
        int t = heap[i]; heap[i] = heap[j]; heap[j] = t;
    }

    // ---- Insertion (Heapify-Up) ----
    void insert(int value) {
        if (size == capacity) { System.out.println("Min Heap is full!"); return; }
        heap[size] = value;
        int current = size;
        size++;
        while (current > 0 && heap[current] < heap[parent(current)]) {
            swap(current, parent(current));
            current = parent(current);
        }
    }

    // ---- Peek ----
    int peek() {
        if (size == 0) throw new IllegalStateException("Min Heap is empty");
        return heap[0];
    }

    // ---- Extract Min (Heapify-Down) ----
    int extractMin() {
        if (size == 0) throw new IllegalStateException("Min Heap is empty");
        int min = heap[0];
        heap[0] = heap[size - 1];
        size--;
        heapifyDown(0);
        return min;
    }

    void heapifyDown(int i) {
        int smallest = i;
        int left  = leftChild(i);
        int right = rightChild(i);
        if (left  < size && heap[left]  < heap[smallest]) smallest = left;
        if (right < size && heap[right] < heap[smallest]) smallest = right;
        if (smallest != i) { swap(i, smallest); heapifyDown(smallest); }
    }

    void display() {
        if (size == 0) { System.out.println("Heap is empty."); return; }
        System.out.print("[ ");
        for (int i = 0; i < size; i++) System.out.print(heap[i] + " ");
        System.out.println("]");
    }

    int getSize() { return size; }
}

public class Lab_10_Task_1 {
    public static void main(String[] args) {
        System.out.println("===== TASK 1: Min Heap Construction & Root Deletion =====\n");

        MinHeap mh = new MinHeap(10);
        int[] values = {40, 15, 30, 10, 50, 20, 25};

        System.out.print("Inserting values : ");
        for (int v : values) System.out.print(v + " ");
        System.out.println("\n");

        for (int v : values) mh.insert(v);

        System.out.print("Min Heap after all insertions : ");
        mh.display();

        System.out.println("Smallest element (peek)       : " + mh.peek());

        System.out.println("\n--- extractMin() #1 ---");
        int m1 = mh.extractMin();
        System.out.println("Removed Min   : " + m1);
        System.out.print("Updated Heap  : ");
        mh.display();

        System.out.println("\n--- extractMin() #2 ---");
        int m2 = mh.extractMin();
        System.out.println("Removed Min   : " + m2);
        System.out.print("Updated Heap  : ");
        mh.display();

        System.out.println("\nFinal number of elements remaining : " + mh.getSize());
    }
}