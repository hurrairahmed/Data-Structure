/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.data_structure;

/**
 *
 * @author pc
 */
import java.util.Stack;

public class Infix_To_Postfix {

    // Returns precedence of operators
    public static int precedence(char ch) {
        switch (ch) {
            case '+':
            case '-':
                return 1;
            case '*':
            case '/':
            case '%':
                return 2;
            default:
                return -1;
        }
    }

    // Checks whether a character is an operand
    public static boolean isOperand(char ch) {
        return Character.isLetterOrDigit(ch);
    }

    // Converts infix expression to postfix expression
    public static String infixToPostfix(String expression) {
        StringBuilder result = new StringBuilder();
        Stack<Character> stack = new Stack<>();

        for (int i = 0; i < expression.length(); i++) {
            char ch = expression.charAt(i);

            // Ignore spaces
            if (ch == ' ') {
                continue;
            }

            // If operand, add directly to output
            if (isOperand(ch)) {
                result.append(ch).append(' ');
            }
            // If opening parenthesis, push to stack
            else if (ch == '(') {
                stack.push(ch);
            }
            // If closing parenthesis, pop until '(' is found
            else if (ch == ')') {
                while (!stack.isEmpty() && stack.peek() != '(') {
                    result.append(stack.pop()).append(' ');
                }
                if (!stack.isEmpty() && stack.peek() == '(') {
                    stack.pop(); // Remove '('
                }
            }
            // If operator
            else {
                while (!stack.isEmpty() && precedence(ch) <= precedence(stack.peek())) {
                    result.append(stack.pop()).append(' ');
                }
                stack.push(ch);
            }
        }

        // Pop remaining operators from stack
        while (!stack.isEmpty()) {
            if (stack.peek() != '(') {
                result.append(stack.pop()).append(' ');
            } else {
                stack.pop();
            }
        }

        return result.toString().trim();
    }

    public static void main(String[] args) {
        String[] testExpressions = {
            "A+B*C",
            "(A+B)*C",
            "A*(B+C)-D",
            "A+B*C-D",
            "(A+B)*(C-D)"
        };

        for (String expression : testExpressions) {
            System.out.println("Infix Expression   : " + expression);
            System.out.println("Postfix Expression : " + infixToPostfix(expression));
            System.out.println("----------------------------------------");
        }
    }
}