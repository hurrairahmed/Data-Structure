/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.data_structure;

    import java.util.Scanner;
import java.util.Stack;
/**
 *
 * @author pc
 */
public class Activity_5_Infix {


    /* ============================================================
       UTILITY METHODS
       ============================================================ */

    // Returns precedence of operators
    public static int precedence(char ch) {
        switch (ch) {
            case '+':
            case '-':
                return 1;
            case '*':
            case '/':
            case '%':
                return 2;
            default:
                return -1;
        }
    }

    // Checks whether a character is an operand
    public static boolean isOperand(char ch) {
        return Character.isLetterOrDigit(ch);
    }

    /* ============================================================
       ACTIVITY 1 : INFIX → POSTFIX
       ============================================================ */
    public static String infixToPostfix(String expression) {
        StringBuilder result = new StringBuilder();
        Stack<Character> stack = new Stack<>();

        for (int i = 0; i < expression.length(); i++) {
            char ch = expression.charAt(i);
            if (ch == ' ') continue;

            if (isOperand(ch)) {
                result.append(ch).append(' ');
            } else if (ch == '(') {
                stack.push(ch);
            } else if (ch == ')') {
                while (!stack.isEmpty() && stack.peek() != '(') {
                    result.append(stack.pop()).append(' ');
                }
                if (!stack.isEmpty() && stack.peek() == '(') stack.pop();
            } else {
                while (!stack.isEmpty() && precedence(ch) <= precedence(stack.peek())) {
                    result.append(stack.pop()).append(' ');
                }
                stack.push(ch);
            }
        }

        while (!stack.isEmpty()) {
            if (stack.peek() != '(') result.append(stack.pop()).append(' ');
            else stack.pop();
        }

        return result.toString().trim();
    }

    /* ============================================================
       ACTIVITY 2 : POSTFIX → INFIX
       ============================================================ */
    public static String postfixToInfix(String expression) {
        Stack<String> stack = new Stack<>();

        for (int i = 0; i < expression.length(); i++) {
            char ch = expression.charAt(i);
            if (ch == ' ') continue;

            if (isOperand(ch)) {
                stack.push(String.valueOf(ch));
            } else {
                String right = stack.pop();
                String left  = stack.pop();
                String combined = "(" + left + " " + ch + " " + right + ")";
                stack.push(combined);
            }
        }
        return stack.pop();
    }

    /* ============================================================
       HELPER : Modified Infix → Postfix (for Prefix conversion)
       ============================================================ */
    private static String infixToPostfixModified(String expression) {
        StringBuilder result = new StringBuilder();
        Stack<Character> stack = new Stack<>();

        for (int i = 0; i < expression.length(); i++) {
            char ch = expression.charAt(i);
            if (ch == ' ') continue;

            if (isOperand(ch)) {
                result.append(ch).append(' ');
            } else if (ch == '(') {
                stack.push(ch);
            } else if (ch == ')') {
                while (!stack.isEmpty() && stack.peek() != '(') {
                    result.append(stack.pop()).append(' ');
                }
                if (!stack.isEmpty() && stack.peek() == '(') stack.pop();
            } else {
                // strict precedence ( > ) for right-associativity
                while (!stack.isEmpty() && precedence(stack.peek()) > precedence(ch)) {
                    result.append(stack.pop()).append(' ');
                }
                stack.push(ch);
            }
        }

        while (!stack.isEmpty()) {
            if (stack.peek() != '(') result.append(stack.pop()).append(' ');
            else stack.pop();
        }

        return result.toString().trim();
    }

    /* ============================================================
       ACTIVITY 3 : INFIX → PREFIX
       ============================================================ */
    public static String infixToPrefix(String expression) {
        // 1. Remove spaces and reverse
        String noSpaces = expression.replaceAll("\\s+", "");
        StringBuilder reversed = new StringBuilder(noSpaces).reverse();

        // 2. Swap parentheses
        for (int i = 0; i < reversed.length(); i++) {
            char ch = reversed.charAt(i);
            if (ch == '(') reversed.setCharAt(i, ')');
            else if (ch == ')') reversed.setCharAt(i, '(');
        }

        // 3. Convert modified infix to postfix
        String postfix = infixToPostfixModified(reversed.toString());

        // 4. Reverse the postfix to get prefix
        String[] tokens = postfix.split("\\s+");
        StringBuilder prefix = new StringBuilder();
        for (int i = tokens.length - 1; i >= 0; i--) {
            prefix.append(tokens[i]);
            if (i > 0) prefix.append(' ');
        }

        return prefix.toString();
    }

    /* ============================================================
       ACTIVITY 4 : PREFIX → POSTFIX
       ============================================================ */
    public static String prefixToPostfix(String expression) {
        Stack<String> stack = new Stack<>();

        for (int i = expression.length() - 1; i >= 0; i--) {
            char ch = expression.charAt(i);
            if (ch == ' ') continue;

            if (isOperand(ch)) {
                stack.push(String.valueOf(ch));
            } else {
                String left  = stack.pop();
                String right = stack.pop();
                String combined = left + " " + right + " " + ch;
                stack.push(combined);
            }
        }
        return stack.pop();
    }

    /* ============================================================
       MAIN MENU
       ============================================================ */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n========== EXPRESSION CONVERSION ==========");
            System.out.println("1. Infix to Postfix");
            System.out.println("2. Postfix to Infix");
            System.out.println("3. Infix to Prefix");
            System.out.println("4. Prefix to Postfix");
            System.out.println("5. Exit");
            System.out.print("\nEnter your choice: ");
            choice = sc.nextInt();
            sc.nextLine(); // consume newline

            if (choice == 5) {
                System.out.println("Exiting program. Goodbye!");
                break;
            }

            if (choice < 1 || choice > 5) {
                System.out.println("Invalid choice! Please try again.");
                continue;
            }

            System.out.print("\nEnter Expression: ");
            String expression = sc.nextLine();

            System.out.println("\nOriginal Expression : " + expression);

            switch (choice) {
                case 1:
                    System.out.println("Converted Expression: " + infixToPostfix(expression));
                    break;
                case 2:
                    System.out.println("Converted Expression: " + postfixToInfix(expression));
                    break;
                case 3:
                    System.out.println("Converted Expression: " + infixToPrefix(expression));
                    break;
                case 4:
                    System.out.println("Converted Expression: " + prefixToPostfix(expression));
                    break;
            }

        } while (choice != 5);

        sc.close();
    }
}