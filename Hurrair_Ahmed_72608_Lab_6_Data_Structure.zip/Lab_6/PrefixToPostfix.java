/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.data_structure;
    import java.util.Stack;

/**
 *
 * @author pc
 */

public class PrefixToPostfix {

    // Converts a prefix expression to postfix notation
    public static String prefixToPostfix(String expression) {
        Stack<String> stack = new Stack<>();

        // Read the expression from right to left
        for (int i = expression.length() - 1; i >= 0; i--) {
            char ch = expression.charAt(i);

            // Ignore spaces
            if (ch == ' ') {
                continue;
            }

            // If operand, push it onto the stack
            if (Character.isLetterOrDigit(ch)) {
                stack.push(String.valueOf(ch));
            }
            // If operator, pop two operands and combine
            else {
                String left = stack.pop();   // first pop = left operand
                String right = stack.pop();  // second pop = right operand

                // Combine as: left + " " + right + " " + operator
                String combined = left + " " + right + " " + ch;
                stack.push(combined);
            }
        }

        // The final element in the stack is the postfix expression
        return stack.pop();
    }

    public static void main(String[] args) {
        String[] testExpressions = {
            "+ A * B C",
            "* + A B C",
            "- * A + B C D",
            "+ A B",
            "* A + B C"
        };

        for (String expression : testExpressions) {
            System.out.println("Prefix Expression  : " + expression);
            System.out.println("Postfix Expression : " + prefixToPostfix(expression));
            System.out.println("----------------------------------------");
        }
    }
}