///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//package com.mycompany.lab_02;
//
///**
// *
// * @author pc
// */
//
////    public static void main(String[] args) {
////        int[] numbers = {45, 12, 78, 23, 9, 56, 34, 89, 17, 63};
////        int sum = 0;
////        int max = numbers[0];
////        int min = numbers[0];
////        for (int num : numbers) {
////            sum += num;
////            if (num > max) {
////                max = num;
////            }
////            if (num < min) {
////                min = num;
////            }
////        }
////        double average = (double) sum / numbers.length;
////        System.out.println("Array: " + java.util.Arrays.toString(numbers));
////        System.out.println("Sum: " + sum);
////        System.out.println("Average: " + average);
////        System.out.println("Maximum: " + max);
////        System.out.println("Minimum: " + min);
////    }
////    public static void main(String[] args) {
////        int[] numbers = {45, 12, 78, 23, 9, 56, 34, 89, 17, 63};
////        for (int i = 0; i < numbers.length; i++) {
////            System.out.println("Element at index " + i + ": " + numbers[i]);
////        }
////    }
//
////    public static void main(String[] args) {
////
////        int[] numbers = {45, 12, 78, 23, 9, 56, 34, 89, 17, 63};
////        int index = 3;          
////        int value = 100;        
////        System.out.print("Original array: ");
////        printArray(numbers);
////        if (index < 0 || index > numbers.length) {
////            System.out.println("Invalid index! Must be between 0 and " + numbers.length);
////            return;
////        }
////        int[] newArray = new int[numbers.length + 1];
////        for (int i = 0; i < index; i++) {
////            newArray[i] = numbers[i];
////        }
////        newArray[index] = value;
////        for (int i = index; i < numbers.length; i++) {
////            newArray[i + 1] = numbers[i];
////        }
////        System.out.print("Array after insertion: ");
////        printArray(newArray);
////    }
////    public static void printArray(int[] arr) {
////        for (int i = 0; i < arr.length; i++) {
////            System.out.print(arr[i]);
////            if (i < arr.length - 1) {
////                System.out.print(", ");
////            }
////        }
////        System.out.println();
////    }
////    public static void main(String[] args) {
////        int[] original = {45, 12, 78, 23, 9, 56, 34, 89, 17, 63};
////        System.out.println("Original array");
////        printArray(original);
////        int deletePos = 5;
////        System.out.println("Delete array ");
////        System.out.println("Delete index " + deletePos);
////        int[] afterDelete = new int[original.length - 1];
////
////        for (int i = 0; i < deletePos; i++) {
////            afterDelete[i] = original[i];
////        }
////
////        for (int i = deletePos + 1; i < original.length; i++) {
////            afterDelete[i - 1] = original[i];
////        }
////
////        System.out.print("after deletion: ");
////        printArray(afterDelete);
////    }
////
////    public static void printArray(int[] arr) {
////        System.out.print("[ ");
////        for (int i = 0; i < arr.length; i++) {
////            System.out.print(arr[i]);
////            if (i < arr.length - 1) {
////                System.out.print(", ");
////            }
////        }
////        System.out.println(" ]");
////    }
////}
////        public static void main(String[] args) {
////        Scanner scanner = new Scanner(System.in);
////        System.out.print("Enter number of rows: ");
////        int rows = scanner.nextInt();
////
////        System.out.print("Enter number of columns: ");
////        int cols = scanner.nextInt();
////        int[][] array = new int[rows][cols];
////        System.out.println("\nEnter the elements row by row:");
////        for (int i = 0; i < rows; i++) {          
////            for (int j = 0; j < cols; j++) {      
////                System.out.print("Element [" + i + "][" + j + "]: ");
////                array[i][j] = scanner.nextInt();
////            }
////        }
////        System.out.println("\nYour 2D array:");
////        for (int i = 0; i < rows; i++) {
////            for (int j = 0; j < cols; j++) {
////                System.out.print(array[i][j] + " ");
////            }
////            System.out.println(); 
////        }
////
////        scanner.close();
////    }
////    public static void main(String[] args) {
////        Scanner input = new Scanner(System.in);
////        System.out.print("Enter number of rows: ");
////        int rows = input.nextInt();
////        System.out.print("Enter number of columns: ");
////        int cols = input.nextInt();
////        int[][] numbers = new int[rows][cols];
////        System.out.println("Enter each element row by row:");
////        for (int i = 0; i < rows; i++) {
////            for (int j = 0; j < cols; j++) {
////                System.out.print("Element at row " + i + ", column " + j + " = ");
////                numbers[i][j] = input.nextInt();
////            }
////        }
////        System.out.println("The 2D array you entered:");
////        for (int i = 0; i < rows; i++) {
////            for (int j = 0; j < cols; j++) {
////                System.out.print(numbers[i][j] + " ");
////            }
////            System.out.println();  
////        }
////
////        input.close();
////    }
////}
////    public static void main(String[] args) {
////        Scanner input = new Scanner(System.in);
////        System.out.print("Enter number of rows: ");
////        int rows = input.nextInt();
////        System.out.print("Enter number of columns: ");
////        int cols = input.nextInt();
////        int[][] table = new int[rows][cols];
////        System.out.println("\nEnter the elements (row by row):");
////        for (int i = 0; i < rows; i++) {
////            for (int j = 0; j < cols; j++) {
////                System.out.print("Element [" + i + "][" + j + "] = ");
////                table[i][j] = input.nextInt();
////            }
////        }
////        System.out.println("\nThe 2D array you entered:");
////        for (int i = 0; i < rows; i++) {
////            for (int j = 0; j < cols; j++) {
////                System.out.print(table[i][j] + " ");
////            }
////            System.out.println();  
////        }
////        int sum = 0;
////        int max = table[0][0];
////        int min = table[0][0];
////        for (int i = 0; i < rows; i++) {
////            for (int j = 0; j < cols; j++) {
////                int value = table[i][j];
////                sum += value;
////                if (value > max) max = value;
////                if (value < min) min = value;
////            }
////        }
////        int totalElements = rows * cols;
////        double average = (double) sum / totalElements;
////        System.out.println("Statistics ");
////        System.out.println("Sum     : " + sum);
////        System.out.println("Average : " + average);
////        System.out.println("Maximum : " + max);
////        System.out.println("Minimum : " + min);
////
////        input.close();
////    }
////    public static void main(String[] args) {
////        Scanner input = new Scanner(System.in);
////        System.out.print("Enter number of rows: ");
////        int rows = input.nextInt();
////        System.out.print("Enter number of columns: ");
////        int cols = input.nextInt();
////        int[][] matrix = new int[rows][cols];
////        System.out.println("\nEnter each element (row by row):");
////        for (int i = 0; i < rows; i++) {
////            for (int j = 0; j < cols; j++) {
////                System.out.print("Element [" + i + "][" + j + "] = ");
////                matrix[i][j] = input.nextInt();
////            }
////        }
////        System.out.println("\nThe 2D array you entered:");
////        for (int i = 0; i < rows; i++) {
////            int rowSum = 0; 
////            for (int j = 0; j < cols; j++) {
////                System.out.print(matrix[i][j] + " ");
////                rowSum += matrix[i][j];  
////            }
////            System.out.println("→ Sum of row " + i + " = " + rowSum);
////        }
////        input.close();
////    }
////    public static void main(String[] args) {
////        Scanner input = new Scanner(System.in);
////        System.out.print("Enter number of rows: ");
////        int rows = input.nextInt();
////        System.out.print("Enter number of columns: ");
////        int cols = input.nextInt();
////        int[][] matrix = new int[rows][cols];
////        System.out.println("\nEnter each element (row by row):");
////        for (int i = 0; i < rows; i++) {
////            for (int j = 0; j < cols; j++) {
////                System.out.print("Element [" + i + "][" + j + "] = ");
////                matrix[i][j] = input.nextInt();
////            }
////        }
////        System.out.println("\nThe 2D array you entered:");
////        for (int i = 0; i < rows; i++) {
////            for (int j = 0; j < cols; j++) {
////                System.out.print(matrix[i][j] + " ");
////            }
////            System.out.println(); 
////        }
////        System.out.println("\n--- Column Sums ---");
////        for (int j = 0; j < cols; j++) {
////            int colSum = 0;
////            for (int i = 0; i < rows; i++) {
////                colSum += matrix[i][j];
////            }
////
////            System.out.println("Sum of column " + j + " = " + colSum);
////        }
////
////        input.close();
////    }
////    public static void main(String[] args) {
////        Scanner scanner = new Scanner(System.in);
////        System.out.print("Enter number of layers: ");
////        int layers = scanner.nextInt();
////        System.out.print("Enter number of rows: ");
////        int rows = scanner.nextInt();
////        System.out.print("Enter number of columns: ");
////        int columns = scanner.nextInt();
////        int[][][] array = new int[layers][rows][columns];
////        System.out.println("Enter the values for each element:");
////        for (int i = 0; i < layers; i++) {
////            for (int j = 0; j < rows; j++) {
////                for (int k = 0; k < columns; k++) {
////                    System.out.print("array[" + i + "][" + j + "][" + k + "] = ");
////                    array[i][j][k] = scanner.nextInt();
////                }
////            }
////        }
////        System.out.println("\nDisplaying all elements of the 3D array:");
////        for (int i = 0; i < layers; i++) {
////            System.out.println("Layer " + i + ":");
////            for (int j = 0; j < rows; j++) {
////                for (int k = 0; k < columns; k++) {
////                    System.out.print(array[i][j][k] + " ");
////                }
////                System.out.println();
////            }
////            System.out.println();
////        }
////
////        scanner.close();
////    }
////    public static void main(String[] args) {
////        Scanner scanner = new Scanner(System.in);
////
////        System.out.print("Enter number of layers: ");
////        int layers = scanner.nextInt();
////        System.out.print("Enter number of rows: ");
////        int rows = scanner.nextInt();
////        System.out.print("Enter number of columns: ");
////        int cols = scanner.nextInt();
////
////        int[][][] array = new int[layers][rows][cols];
////
////        System.out.println("Enter the values:");
////        for (int i = 0; i < layers; i++) {
////            for (int j = 0; j < rows; j++) {
////                for (int k = 0; k < cols; k++) {
////                    System.out.print("array[" + i + "][" + j + "][" + k + "] = ");
////                    array[i][j][k] = scanner.nextInt();
////                }
////            }
////        }
////
////        int sum = 0;
////        int max = array[0][0][0];
////        int min = array[0][0][0];
////
////        for (int i = 0; i < layers; i++) {
////            for (int j = 0; j < rows; j++) {
////                for (int k = 0; k < cols; k++) {
////                    int value = array[i][j][k];
//////                    sum += value;
//////                    if (value > max) {
//////                        max = value;
//////                    }
//////                    if (value < min) {
//////                        min = value;
//////                    }
//////                }
//////            }
//////        }
//////
//////        double average = (double) sum / (layers * rows * cols);
//////
//////        System.out.println("Sum: " + sum);
//////        System.out.println("Average: " + average);
//////        System.out.println("Maximum: " + max);
//////        System.out.println("Minimum: " + min);
//////
//////        scanner.close();
//////    }
//////    public static void main(String[] args) {
//////        Scanner scanner = new Scanner(System.in);
//////
//////        System.out.print("Enter number of layers: ");
//////        int layers = scanner.nextInt();
//////        System.out.print("Enter number of rows: ");
//////        int rows = scanner.nextInt();
//////        System.out.print("Enter number of columns: ");
//////        int cols = scanner.nextInt();
//////
//////        int[][][] array = new int[layers][rows][cols];
//////
//////        System.out.println("Enter the elements:");
//////        for (int i = 0; i < layers; i++) {
//////            for (int j = 0; j < rows; j++) {
//////                for (int k = 0; k < cols; k++) {
//////                    System.out.print("array[" + i + "][" + j + "][" + k + "] = ");
//////                    array[i][j][k] = scanner.nextInt();
//////                }
//////            }
//////        }
////
//////        System.out.println("\nSum of each layer:");
//////        for (int i = 0; i < layers; i++) {
//////            int layerSum = 0;
//////            for (int j = 0; j < rows; j++) {
//////                for (int k = 0; k < cols; k++) {
//////                    layerSum += array[i][j][k];
//////                }
//////            }
//////            System.out.println("Layer " + i + " sum = " + layerSum);
//////        }
//////
//////        scanner.close();
//////    
////    public static void main(String[] args) {
////        Scanner scanner = new Scanner(System.in);
////
////        System.out.print("Enter depth (number of 2D arrays): ");
////        int depth = scanner.nextInt();
////        System.out.print("Enter number of rows: ");
////        int rows = scanner.nextInt();
////        System.out.print("Enter number of columns: ");
////        int cols = scanner.nextInt();
////
////        int[][][] array = new int[depth][rows][cols];
////
////        System.out.println("Enter the elements for the 3D array:");
////        for (int i = 0; i < depth; i++) {
////            for (int j = 0; j < rows; j++) {
////                for (int k = 0; k < cols; k++) {
////                    System.out.print("Element at [" + i + "][" + j + "][" + k + "]: ");
////                    array[i][j][k] = scanner.nextInt();
////                }
////            }
////        }
////
////        System.out.print("Enter the value to search: ");
////        int searchVal = scanner.nextInt();
////
////        boolean found = false;
////        for (int i = 0; i < depth; i++) {
////            for (int j = 0; j < rows; j++) {
////                for (int k = 0; k < cols; k++) {
////                    if (array[i][j][k] == searchVal) {
////                        System.out.println("Found at position [" + i + "][" + j + "][" + k + "]");
////                        found = true;
////                    }
////                }
////            }
////        }
////
////        if (!found) {
////            System.out.println("Value not found in the array.");
////        }
////
////        scanner.close();
////    }
////    public static void main(String[] args) {
////        int[] arr = {64, 25, 12, 22, 11, 90, 34};
////        System.out.print("Original: ");
////        printArray(arr);
////        bubbleSort(arr);
////        System.out.print("Sorted  : ");
////        printArray(arr);
////    }
////
////    public static void bubbleSort(int[] arr) {
////        int n = arr.length;
////        for (int i = 0; i < n - 1; i++) {
////            boolean swapped = false;
////            for (int j = 0; j < n - i - 1; j++) {
////                if (arr[j] > arr[j + 1]) {
////                    int temp = arr[j];
////                    arr[j] = arr[j + 1];
////                    arr[j + 1] = temp;
////                    swapped = true;
////                }
////            }
////            if (!swapped) break;
////        }
////    }
////
////    public static void printArray(int[] arr) {
////        for (int num : arr) System.out.print(num + " ");
////        System.out.println();
////    }
////    public static void main(String[] args) {
////        int[] arr = {64, 25, 12, 22, 11, 90, 34};
////        System.out.print("Original: ");
////        printArray(arr);
////        selectionSort(arr);
////        System.out.print("Sorted  : ");
////        printArray(arr);
////    }
////
////    public static void selectionSort(int[] arr) {
////        int n = arr.length;
////        for (int i = 0; i < n - 1; i++) {
////            int minIdx = i;
////            for (int j = i + 1; j < n; j++) {
////                if (arr[j] < arr[minIdx]) {
////                    minIdx = j;
////                }
////            }
////            int temp = arr[minIdx];
////            arr[minIdx] = arr[i];
////            arr[i] = temp;
////        }
////    }
////
////    public static void printArray(int[] arr) {
////        for (int num : arr) System.out.print(num + " ");
////        System.out.println();
////    }
////    public static void main(String[] args) {
////        int[] arr = {64, 25, 12, 22, 11, 90, 34};
////        System.out.print("Original: ");
////        printArray(arr);
////        insertionSort(arr);
////        System.out.print("Sorted  : ");
////        printArray(arr);
////    }
////
////    public static void insertionSort(int[] arr) {
////        int n = arr.length;
////        for (int i = 1; i < n; i++) {
////            int key = arr[i];
////            int j = i - 1;
////            while (j >= 0 && arr[j] > key) {
////                arr[j + 1] = arr[j];
////                j--;
////            }
////            arr[j + 1] = key;
////        }
////    }
////
////    public static void printArray(int[] arr) {
////        for (int num : arr) System.out.print(num + " ");
////        System.out.println();
////    }
//        class Node {
//    int data;
//    Node next;
//
//    Node(int data) {
//        this.data = data;
//        this.next = null;
//    }
//}
//
//class LinkedList {
//    Node head;
//
//    LinkedList() {
//        head = null;
//    }
//
//    void createFromList(int[] values) {
//        if (values.length == 0) return;
//        head = new Node(values[0]);
//        Node current = head;
//        for (int i = 1; i < values.length; i++) {
//            current.next = new Node(values[i]);
//            current = current.next;
//        }
//    }
//
//    void traverse() {
//        Node current = head;
//        while (current != null) {
//            System.out.print(current.data + " → ");
//            current = current.next;
//        }
//        System.out.println("null");
//    }
//
//    void insertBeginning(int data) {
//        Node newNode = new Node(data);
//        newNode.next = head;
//        head = newNode;
//    }
//
//    void insertEnd(int data) {
//        Node newNode = new Node(data);
//        if (head == null) {
//            head = newNode;
//            return;
//        }
//        Node current = head;
//        while (current.next != null) {
//            current = current.next;
//        }
//        current.next = newNode;
//    }
//
//    void search(int target) {
//        Node current = head;
//        int position = 0;
//        while (current != null) {
//            if (current.data == target) {
//                System.out.println("Value " + target + " found at position " + position);
//                return;
//            }
//            current = current.next;
//            position++;
//        }
//        System.out.println("Value " + target + " not found");
//    }
//
//    void delete(int target) {
//        if (head == null) {
//            System.out.println("List is empty, nothing to delete");
//            return;
//        }
//        if (head.data == target) {
//            head = head.next;
//            System.out.println("Deleted " + target);
//            return;
//        }
//        Node current = head;
//        while (current.next != null && current.next.data != target) {
//            current = current.next;
//        }
//        if (current.next == null) {
//            System.out.println("Value " + target + " not found, nothing deleted");
//        } else {
//            current.next = current.next.next;
//            System.out.println("Deleted " + target);
//        }
//    }
//
//    void display() {
//        traverse();
//    }
//}
//
//public class lab_2 {
//    public static void main(String[] args) {
//        LinkedList ll = new LinkedList();
//
//        System.out.println("A. Create & Traverse:");
//        ll.createFromList(new int[]{10, 20, 30, 40, 50});
//        ll.traverse();
//
//        System.out.println("\nB. Insert at Beginning (5):");
//        ll.insertBeginning(5);
//        ll.traverse();
//
//        System.out.println("\nC. Insert at End (60):");
//        ll.insertEnd(60);
//        ll.traverse();
//
//        System.out.println("\nD. Search for 30:");
//        ll.search(30);
//
//        System.out.println("\nE. Delete value 20:");
//        ll.delete(20);
//        ll.traverse();
//
//        System.out.println("\nF. Final Display:");
//        ll.display();
//    }
//}
